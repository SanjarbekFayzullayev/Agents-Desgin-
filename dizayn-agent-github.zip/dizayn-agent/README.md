# Dizayn Agent

Tasbeh loyihasi (ilova + market) uchun AI dizayn jamoasi: uchta agent, beshta
buyruq, doimiy xotira va 14 bo'limli bilim bazasi.

## Agentlar

| Agent | Vazifasi |
|---|---|
| `art-direktor` | Kreativ yo'nalish tanlaydi, dizayn-tizim quradi, tayyor dizaynni (HTML/CSS/SVG) yasaydi |
| `brend-strateg` | Auditoriya, pozitsiya, farqlanish, ovoz ohangi, nom va shior, dizayner uchun brif |
| `dizayn-tanqidchi` | Mustaqil tekshiruv: 9 mezon bo'yicha ball, hurmat va aniqlik tekshiruvi, tuzatishlar |

## Buyruqlar

| Buyruq | Qachon ishlatiladi |
|---|---|
| `/dizayn-agent:dizayn` | Har qanday dizayn ishi: ilova ekrani, market, post, banner, landing |
| `/dizayn-agent:dizayn-audit` | Mavjud dizaynni baholash, variantlarni solishtirish |
| `/dizayn-agent:brend-kit` | Logo, ranglar, shriftlar, brend qo'llanmasi |
| `/dizayn-agent:kontent-tizim` | Instagram/Telegram shablonlar, karusel, video raskadrovka |
| `/dizayn-agent:xotira` | Xotirani ko'rish, yangilash, biror narsani eslab qolish yoki unutish |

Buyruq yozish shart emas: oddiy so'rov yetarli ("hisoblagich ekranini dizayn
qil", "market sahifasini baholang", "nimani eslaysan?").

## Xotira qanday ishlaydi

Agent `DIZAYN-XOTIRA.md` faylini yuritadi: brend profili, tasdiqlangan qarorlar,
sizning didingiz va fikrlaringiz, fayllar holati, ish jurnali.

- Har ish boshida faylni o'qiydi va bilgan narsasini qayta so'ramaydi.
- Har ish oxirida yangi qaror va fikrlarni yozib qo'yadi.
- Fayl oddiy matn: o'zingiz ham ochib tahrirlashingiz mumkin.

Xotira saqlanishi uchun agentga doimiy joy kerak:

- **Cowork + ulangan papka** (tavsiya): loyiha papkasini ulang, fayl o'sha yerda
  saqlanadi va har safar o'zi topiladi.
- **Claude Code**: fayl loyiha papkasida turadi.
- **Oddiy chat**: agent yangilangan faylni sizga beradi; keyingi safar uni
  biriktirasiz yoki Project fayllariga qo'yasiz.

Parol, karta ma'lumoti va mijozlarning shaxsiy ma'lumotlari xotiraga yozilmaydi.

## Tasbeh loyihasi qoidalari

`tasbeh-project.md` ichida. Eng muhimlari:

- Oyat, zikr, duo va hadis matnlari agent tomonidan o'ylab topilmaydi: faqat
  siz bergan va tasdiqlagan matn ishlatiladi, aks holda belgilangan bo'sh joy
  qoldiriladi.
- Arabcha matn to'g'ri (o'ngdan chapga, ulangan harflar bilan) ko'rsatiladi.
- Hisoblash ekranida reklama bo'lmaydi; ibodatni o'yinga aylantiruvchi bosim
  ishlatilmaydi.
- Diniy kontentni chop etishdan oldin mutaxassis ko'rib chiqishi tavsiya
  etiladi.

## Bilim bazasi

`skills/dizayn/references/` ichida: `tasbeh-project.md`, `typography-color.md`,
`layout-composition.md`, `formats.md`, `conversion-copy.md`,
`style-directions.md`, `industry-playbooks.md`, `ux-product.md`,
`social-system.md`, `brand-strategy.md`, `image-briefs.md`,
`critique-rubric.md`, `examples.md`, `brand-profile-template.md`.

## O'rnatish

**Fayl orqali**: Claude Desktop -> Cowork -> Customize -> plaginlar -> Upload
plugin, `dizayn-agent.plugin` (qabul qilinmasa nomini `.zip` ga o'zgartiring).

**GitHub orqali**: bu papka `.claude-plugin/marketplace.json` bilan birga
GitHub repozitoriyasiga joylanadi; keyin Claude'da plaginlar bo'limida
repozitoriy manzili marketplace sifatida qo'shiladi va plagin o'sha yerdan
o'rnatiladi. Claude Code'da:

```
/plugin marketplace add <egasi>/<repo>
/plugin install dizayn-agent@masalahal-plugins
```

## Cheklovlar

- Agent foto generatsiya qilmaydi: dizaynni HTML/CSS/SVG bilan quradi, foto
  uchun brif yoki prompt beradi.
- Sub-agentlar Cowork va Claude Code'da ishlaydi; oddiy chatda faqat
  skill'lar ishlaydi.
- Do'kon (Google Play, App Store) va reklama o'lchamlari o'zgarib turadi,
  yuklashdan oldin joriy talablarni tekshiring.
- Nom va logoning huquqiy bo'shligini agent tasdiqlay olmaydi.
