---
name: dizayn-audit
description: This skill should be used when the user asks to review, audit, rate, critique or compare existing design - "dizaynni baholang", "saytimni ko'rib bering", "bu post yaxshimi", "qaysi variant yaxshi", "nima xato", "audit qil", "design review", "rate this design" - for a screenshot, link, page, post, logo, deck or file. It produces a scored report with prioritized fixes and can follow with a redesign.
---

# Dizayn audit

Give the owner an honest verdict and the shortest path to a better result.

Memory: follow the `xotira` skill. Read `DIZAYN-XOTIRA.md` before starting and update it before the final message. For the tasbeh project, apply `../dizayn/references/tasbeh-project.md`, including its respect and accuracy rules.

## Steps

1. **Get the design in view.** Read the attached image or file; for a link, open
   it with the available browser or fetch tool and look at both desktop and mobile
   widths when possible. If the design cannot actually be seen, ask for a
   screenshot rather than reviewing from a description.
2. **Establish goal and audience** from context; state the assumption if unknown.
3. **Run the review.** Delegate to the dizayn-tanqidchi agent when the session can
   launch agents; otherwise apply the same rubric yourself. The rubric and report
   format are in `../dizayn/references/critique-rubric.md`.
4. **Check the technical layer** where relevant: contrast (use
   `../dizayn/scripts/contrast.py`), dimensions and safe zones
   (`../dizayn/references/formats.md`), mobile layout, loading weight, missing
   states.
5. **For selling pieces**, review the offer, headline, CTA and proof against
   `../dizayn/references/conversion-copy.md`. A design problem is often an offer
   problem; say so when it is.
6. **Deliver the report** in the user's language: overall score, first impression,
   strengths, top problems in order of impact with exact fixes, score table, quick
   fixes, verdict. Keep it to one screen unless depth is requested.
7. **Offer the next step**: a redesigned version applying the top fixes, built
   through the `dizayn` skill. If the user asked to "improve" rather than only
   "review", do the redesign in the same turn and show before and after.

## Standards

- Be specific and evidence-based: name the element, the problem, the fix, with
  sizes and colors.
- Do not inflate scores. An honest low score with a clear fix is more useful to
  someone spending money than a polite high one.
- Prioritize: three fixes that move the result, not twenty notes.
- Separate taste from function. Mark which findings are objective (contrast,
  size, cut-off text) and which are judgment calls.
- When comparing variants, apply the same rubric to each, name the winner and
  what to borrow from the other.
