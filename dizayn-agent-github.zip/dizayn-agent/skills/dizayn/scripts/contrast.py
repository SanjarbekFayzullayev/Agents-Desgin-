#!/usr/bin/env python3
"""WCAG 2.x contrast checker.

Usage:
    python contrast.py "#0f3d3e" "#ffffff"
    python contrast.py "#ff6a3d" "#1a0e09" "#fbfaf7" "#5c594f"   # pairs: fg bg fg bg

Prints the contrast ratio for each foreground/background pair and whether it
passes for body text (4.5:1), large text / UI components (3:1) and AAA (7:1).
"""
import sys


def parse_hex(value: str):
    v = value.strip().lstrip("#")
    if len(v) == 3:
        v = "".join(c * 2 for c in v)
    if len(v) != 6:
        raise ValueError(f"Not a hex color: {value!r}")
    return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))


def luminance(rgb):
    def channel(c):
        c = c / 255
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

    r, g, b = (channel(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(fg: str, bg: str) -> float:
    l1, l2 = luminance(parse_hex(fg)), luminance(parse_hex(bg))
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def main(argv):
    if len(argv) < 2 or len(argv) % 2:
        print(__doc__)
        return 2
    worst = 0
    for i in range(0, len(argv), 2):
        fg, bg = argv[i], argv[i + 1]
        try:
            r = ratio(fg, bg)
        except ValueError as exc:
            print(exc)
            return 2

        def mark(ok):
            return "PASS" if ok else "FAIL"

        print(
            f"{fg} on {bg}: {r:.2f}:1 | body text 4.5 {mark(r >= 4.5)} | "
            f"large text/UI 3.0 {mark(r >= 3)} | AAA 7.0 {mark(r >= 7)}"
        )
        if r < 3:
            worst = 1
    return worst


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
