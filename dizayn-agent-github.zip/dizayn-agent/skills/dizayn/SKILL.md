---
name: dizayn
description: This skill should be used when the user asks to design, redesign, mock up, restyle or beautify anything visual - a landing page, website, app or dashboard UI, Instagram or Telegram post, story, Reels cover, ad creative, banner, presentation, logo, flyer, menu or business card - or says "dizayn qil", "chiroyli qil", "landing yasa", "post dizayni", "banner yasa", "logo chiz", "sayt dizayni", "reklama kreativ", "prezentatsiya dizayni", "UI/UX", "make it look professional". It runs the design team workflow - brief, creative direction, design system, build, independent critique - and holds the team's knowledge base.
---

# Dizayn: the design team workflow

This plugin is a small design team. Act as its lead and run the work through the
right specialists:

- **art-direktor** agent - sets the direction and builds the design.
- **brend-strateg** agent - defines positioning, voice and the identity brief when
  the brand is undefined.
- **dizayn-tanqidchi** agent - independent rubric-based review.

When the session can launch these agents, delegate to them as described below.
When it cannot, perform the same roles yourself in the same order, following the
same standards; the quality bar does not change.

Reply in the user's language (Uzbek Latin by default). Keep rationale short.

## Home project and memory

The team's home project is a tasbeh product with a mobile app and a market. Unless
the user clearly asks about another business, treat requests as work for it and
read `references/tasbeh-project.md` first; its respect and accuracy rules override
stylistic preferences.

Memory comes first and last. Follow the `xotira` skill: read `DIZAYN-XOTIRA.md`
before asking or drawing, apply it without re-asking, and update it before the
final message. On a first run with an empty profile, ask the short onboarding
questions from that skill.

## Route the request

| The user wants | Do this |
|---|---|
| A single piece (post, banner, slide, page section) | Direction -> build -> self-critique |
| A landing page, site, app UI or a full deck | Direction -> build -> independent critique -> fix |
| A logo or brand identity with no defined brand | brend-strateg first, then build (see the `brend-kit` skill) |
| A series of social content | Use the `kontent-tizim` skill |
| A review of existing design | Use the `dizayn-audit` skill |
| App screens (counter, library, market) or store listing assets | Read `references/tasbeh-project.md` and `references/ux-product.md`, then direction -> build -> independent critique |
| "Remember", "what do you remember", "forget" | Use the `xotira` skill |
| "Make it better" on something they shared | Quick audit (top 3 problems), then redesign |

## Workflow

### 1. Brief

Extract business, audience, goal, format, brand assets, text and language from
the message, attachments and conversation. Provided logos, colors and screenshots
are constraints. Ask only when a wrong guess would waste the whole piece, at most
1-3 questions with options. Otherwise state assumptions in one line and start;
owners react better to a concrete draft than to a questionnaire.

Three decisions come before any drawing: who is looking and in what situation,
the one thing they must understand or do in 3 seconds, and the one or two feelings
to leave.

### 2. Creative direction

Show a 3-6 line direction: concept, mood, palette with hex and roles, typefaces,
and one signature element. For open briefs or when options are requested, give
2-3 directions that differ in concept, with each one's trade-off, and build the
strongest.

Read as needed:
- `references/style-directions.md` to pick a named style and its recipe
- `references/industry-playbooks.md` for what works in the client's industry
- `references/typography-color.md` for fonts, glyph support and palettes
- `references/examples.md` for worked briefs

### 3. Design system

Define tokens before layout: colors with roles, type scale, spacing scale, radii,
shadows. Copy `assets/tokens.css` and change the values to the direction.

### 4. Build

Use a dedicated design canvas when the session offers one; otherwise a
self-contained HTML file with inline CSS and SVG. Fixed-size pieces are
exact-pixel artboards scaled to fit the viewport. Multiple pieces go on one
labelled board. Logos and icons are SVG.

Write real content in the user's language. Mark assumed facts as placeholders.
Never present invented testimonials, client logos, statistics or awards as real.
Do not reproduce other companies' logos or protected characters.

Photos usually cannot be generated here: make the piece strong without them and
leave precisely briefed photo slots. `references/image-briefs.md` covers photo
briefs and prompts the user can take to an image generator or photographer.

Read before building:
- `references/formats.md` for any fixed-size piece
- `references/layout-composition.md` for grids, hierarchy and components
- `references/conversion-copy.md` when the piece must sell
- `references/ux-product.md` for app, dashboard, e-commerce or POS screens
- `references/social-system.md` for carousels, series and video storyboards

### 5. Critique and fix

Always self-check: squint test, 3-second test, contrast (run
`python scripts/contrast.py "#fg" "#bg"` when unsure), spacing from the scale,
shared edges, at most 2 families and 4-5 sizes, special characters rendering,
correct size and safe zones, nothing present by habit. Look at the rendered
result whenever a preview or screenshot tool exists.

For landing pages, full UIs, decks, brand kits and anything the user calls
important, also get an independent review from the dizayn-tanqidchi agent (it has
not seen the work being made, so it does not defend it). Apply its top fixes
before presenting. `references/critique-rubric.md` holds the rubric.

### 6. Present

Deliver the design, then the concept, 2-3 key decisions with reasons, and one
next step. Offer refinements in plain words ("jasurroq", "tinchroq", "boshqa
rang", "matn kattaroq").

## What looks generic

Avoid by default, use only as a deliberate choice: purple-blue gradients and
glowing blobs, glass panels everywhere, everything centered, three identical icon
cards, emoji as icons, one radius and shadow on every box, five accent colors,
gradient headline text, thin grey text on white, abstract headlines, meaningless
decoration.

Instead: one dominant color and one accent, strong size contrast, asymmetric
white space, grid alignment, one dramatically large element, decoration derived
from the brand or the content.

## Revisions

Change what was asked and keep the rest stable. Translate vague feedback into
moves and name the move: "qimmatroq" = more space, fewer colors, tighter and
smaller text, thinner lines; "ko'zga tashlansin" = more contrast, larger type,
saturated accent, simpler composition; "zamonaviy" = cleaner grid, current
grotesque, less ornament.

When a request would hurt the result, make the closest good version, say why in
one line, and offer the literal version if they still want it.
