# UX and Product UI

For apps, dashboards, online stores and POS screens. Marketing layouts are
covered in `layout-composition.md`.

## Contents
1. Start from the task
2. Usability heuristics
3. Navigation and information architecture
4. Forms
5. States and feedback
6. Mobile patterns
7. E-commerce patterns
8. POS and operator screens
9. Admin and dashboard patterns
10. Accessibility
11. Microcopy
12. Deliverables for a UI task

## 1. Start from the task

Before screens, write: who the user is, the top 3 tasks they come to do, and the
shortest path for each. Design the most frequent task to take the fewest steps.
A screen that looks good but adds a step to the main task is a worse design.

Sketch the flow as a list of screens and decisions first. Then design the key
screen (the one used most), then the rest in its language.

## 2. Usability heuristics

Check every screen against these (after Nielsen):

1. The system shows what is happening (loading, saved, error).
2. It speaks the user's language, not the developer's.
3. Users can undo and go back.
4. Same thing looks and works the same everywhere.
5. Prevent errors before they happen (constraints, confirmations for
   destructive actions).
6. Show options instead of making users remember.
7. Shortcuts for frequent users.
8. Only what is needed on screen.
9. Error messages say what happened and how to fix it.
10. Help is available where it is needed.

## 3. Navigation and information architecture

- Group by the user's mental model (their tasks), not by the company's
  departments or database tables.
- 5-7 top-level items at most. Name items with plain nouns the user would say.
- Always show where the user is (active state, title, breadcrumbs for depth).
- Search for anything with more than about 30 items.
- Mobile app: bottom tab bar with 3-5 destinations. Web app: left sidebar for
  many sections, top bar for few.

## 4. Forms

- Ask only for what is needed now. Every field removed raises completion.
- One column. Labels above fields, always visible. Placeholders are examples,
  not labels.
- Group related fields; split long forms into clear steps with a progress
  indicator.
- Right input type and keyboard for each field (phone, number, date picker).
- Validate inline, after the user leaves the field, in plain words next to the
  field. Keep what the user typed.
- Smart defaults and masks (+998 __ ___ __ __).
- Primary button states what happens ("Buyurtma berish"); disable it only with a
  visible reason.

## 5. States and feedback

Design every screen in all its states: empty (with a prompt for the first
action), loading (skeletons for content, spinners for short actions), partial,
error (what happened, what to do), success (confirmation and next step), and
offline when relevant. Destructive actions need confirmation or an undo.
Feedback appears within 100ms of an action, even if the result takes longer.

## 6. Mobile patterns

- Thumb zone: primary actions in the lower half; destructive actions away from
  frequent ones.
- Touch targets 44px or more, 8px apart.
- Bottom sheets for short choices; full screens for complex tasks.
- 16px minimum body text; avoid hover-only interactions.
- Keep the primary CTA visible (sticky) on long screens.
- Respect system safe areas at the top and bottom.

## 7. E-commerce patterns

- **Catalog**: consistent image ratio, name limited to 2 lines, price prominent,
  availability and delivery hints, filters that match how people choose.
- **Product page**: large images first, price and buy button visible without
  scrolling on mobile, key facts as short bullets, delivery and payment
  information beside the button, reviews, related items.
- **Cart and checkout**: show the total with delivery early, allow guest
  checkout, few fields, local payment methods clearly marked, order summary
  always visible, a confirmation screen with the order number and next steps.
- **Trust**: real contacts, return and delivery terms, working hours.
- **Search**: tolerant of typos and of Latin/Cyrillic variants.

## 8. POS and operator screens

Operators use these all day, fast, often standing, sometimes on touch screens.

- Speed over beauty: the most frequent action (add item, take payment) is one
  tap, large and always in the same place.
- Big targets (56px+), high contrast, large numbers for totals.
- Keyboard and barcode scanner support; focus stays in the search field.
- Clear, hard-to-miss confirmation of payment; errors are loud and specific.
- Protect against costly mistakes: confirm refunds and deletions, show what
  will change.
- Work when the connection drops, and show sync status.
- Calm neutral interface with color reserved for status (paid, unpaid, error).
- Layout stays stable; elements never move between states.

## 9. Admin and dashboard patterns

- First screen answers "how is the business today": 3-5 key numbers with
  comparison to the previous period.
- Tables: sortable, filterable, with bulk actions and saved views; right-align
  numbers; sticky header; row height 48-56px.
- Detail pages: summary at the top, tabs for sections, actions grouped at the
  top right.
- Use plain words for statuses and one consistent color per status.

## 10. Accessibility

- Contrast 4.5:1 for text, 3:1 for large text and interface elements.
- Never rely on color alone; add an icon or a label.
- Visible focus states; logical tab order; all controls reachable by keyboard.
- Text can scale to 200% without breaking layout.
- Alt text for meaningful images; real `button` and `label` elements.
- Respect reduced-motion settings.

## 11. Microcopy

- Buttons: verb + object ("Mahsulot qo'shish").
- Errors: what happened and what to do ("Telefon raqami to'liq emas. 9 ta raqam
  kiriting").
- Empty states: what this is for and the first step.
- Consistent terms: one word for one thing across the product.
- Write in the user's everyday language; avoid technical terms and codes.

## 12. Deliverables for a UI task

1. Flow list: screens and the path through them.
2. Tokens: colors, type, spacing, radii.
3. Key screens in the main state, at mobile and desktop sizes as relevant.
4. Important states: empty, loading, error, success.
5. A component sheet: buttons, inputs, cards, table row, navigation.
6. Short notes on behavior the visuals cannot show.
