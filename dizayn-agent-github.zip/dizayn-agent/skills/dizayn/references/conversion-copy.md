# Conversion Design and Copy

Design that must sell is judged by actions taken, not by beauty. Layout, copy and
offer work together; a weak headline cannot be rescued by a good palette.

## Contents
1. Before designing: the offer
2. Landing page blueprint
3. Headlines
4. CTAs and forms
5. Trust and proof
6. Ad creative formulas
7. Local market notes
8. What to test

## 1. Before designing: the offer

Answer these in one line each. If the user has not provided them, infer and state
the assumption.

- Who exactly is this for? (for example: do'kon egalari, 1-5 filial)
- What painful problem do they have now?
- What concrete result do they get, and how fast?
- Why believe it? (numbers, cases, guarantee, demo)
- What is the single next step, and what does it cost them (time, money, risk)?

## 2. Landing page blueprint

1. **Hero**: result-focused headline, one clarifying sentence, primary CTA, and a
   visual of the product or outcome. Add a low-risk note under the button
   ("Bepul konsultatsiya, 15 daqiqa").
2. **Proof strip**: numbers that matter (clients, years, results), ratings or
   client logos the user actually has.
3. **Problem**: 3-4 pains in the customer's own words.
4. **Solution**: what you do, shown visually (screens, before/after, process).
5. **Benefits**: 3-6 outcomes, each with a short proof or example.
6. **How it works**: 3-4 steps with time frames.
7. **Cases / testimonials**: real names, photos, numbers. If none are provided,
   leave a clearly marked slot; never invent them.
8. **Offer and pricing**: what is included, price or "from" price, bonus or
   deadline if real.
9. **FAQ**: handle objections about price, time, risk, support.
10. **Final CTA**: repeat the offer; give two contact routes (form + Telegram or
    phone).

One page, one goal. Remove links and elements that lead away from the main action.

## 3. Headlines

A good headline is specific enough that a competitor could not use it unchanged.

Formulas:
- **Result + time frame**: "Do'koningizni 7 kunda onlayn savdoga ulaymiz"
- **Result without the pain**: "Hisob-kitobni Excel'siz yuriting"
- **Number + outcome**: "Kassadagi xatolarni 3 baravar kamaytiring"
- **For whom + what**: "Kitob do'konlari uchun tayyor onlayn market va kassa"
- **Question that names the pain**: "Tovar qoldig'ini hali ham qo'lda sanayapsizmi?"

Avoid abstractions ("innovatsion yechimlar", "yangi bosqich", "sifat va
ishonch"). Replace every adjective with a fact or a number where possible.
Only use numbers and claims the user has given or can stand behind; mark assumed
figures as placeholders to confirm.

## 4. CTAs and forms

- The button says what happens next: "Demo ko'rish", "Narxni hisoblash",
  "Telegramda yozish". Not "Yuborish" or "Batafsil".
- One primary CTA style, repeated after every major section.
- The CTA color is the accent color and appears nowhere else at that strength.
- Forms: name + phone is often enough. Each extra field lowers completion.
  Use the +998 phone mask, a large tappable button, and say when the reply comes.
- Offer a messenger route beside the form; many customers prefer Telegram to
  forms.
- On mobile, keep a sticky CTA bar on long pages.

## 5. Trust and proof

In order of strength: a named case with numbers, video or photo testimonials,
recognizable client logos, guarantees, years and volume in numbers, the team's
faces, certificates, a clear address and working contacts.

Place proof next to the claim it supports and next to the CTA. A real photo of
the team or the product beats any stock image.

## 6. Ad creative formulas

- **Pain -> solution**: name the pain in the hook, show the fix.
- **Before / after**: split frame, same angle, clear labels.
- **Number hook**: one big figure with a short line explaining it.
- **Offer**: what, how much, until when. Deadline only if real.
- **Social proof**: short client quote with name and business.
- **Demonstration**: the product in use, with one caption.
- **Question**: a question the audience answers "yes, that's me" to.

Text on the creative: hook (3-7 words) + offer line + CTA. Details go in the
caption. Check that the hook is readable in a feed at thumbnail size.

## 7. Local market notes

Useful defaults for Uzbekistan-based clients; adjust when the user says otherwise.

- Telegram is a primary business channel: include a Telegram handle or link as a
  first-class CTA, and design Telegram-friendly images.
- Most traffic is mobile, often from Instagram. Mobile layout comes first.
- Audiences are often bilingual. Ask or infer the language (Uzbek Latin, Uzbek
  Cyrillic, Russian); for mixed audiences, design layouts that survive the longer
  language.
- Prices: write as "12 000 000 so'm" with spaces as thousands separators.
- Phone format: +998 90 123 45 67.
- Trust is personal: founder's face, real client names, and concrete local cases
  are especially persuasive.
- Respect cultural context in imagery and seasonal campaigns (Navro'z, Ramazon,
  Mustaqillik kuni); keep visuals modest and respectful by default.

## 8. What to test

Suggest one test at a time, in order of likely impact: the offer, the headline or
hook, the hero visual, the CTA text, then colors and layout details. Colors rarely
change results as much as the offer and the first line do.
