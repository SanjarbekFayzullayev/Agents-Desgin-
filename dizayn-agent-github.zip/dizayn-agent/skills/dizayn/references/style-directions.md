# Style Directions Library

Named visual styles with recipes. Pick one as the base for a creative direction,
then adapt it to the brand; do not mix more than two. Each entry lists when it
fits, the recipe, and the risk.

## Contents
1. Swiss / International
2. Editorial
3. Premium minimal
4. Bold commercial
5. Neo-brutalist
6. Bento / modular
7. Soft friendly
8. Dark tech
9. Warm craft
10. Heritage / ornamental
11. Retro pop
12. Data-forward
13. How to choose

## 1. Swiss / International
**Fits**: B2B, IT services, consulting, anything that must look organized.
**Recipe**: strict grid, left-aligned grotesque (Inter, Golos, Onest), large
tight headlines, one accent color on white or black, thin rules, numbered
sections, no decoration.
**Risk**: cold or anonymous. Fix with one bold move: a huge numeral or a single
saturated color block.

## 2. Editorial
**Fits**: education, books, media, experts' personal brands, premium services.
**Recipe**: serif display (Playfair Display, Lora, PT Serif) with a quiet sans
for text, magazine-like columns, large pull quotes, generous margins, photo with
captions, ivory or paper-tinted background, ink-colored text.
**Risk**: hard to read on small screens if the serif is too thin. Use medium
weights and larger sizes on mobile.

## 3. Premium minimal
**Fits**: beauty, fashion, jewelry, real estate, high-ticket services.
**Recipe**: lots of empty space, small refined type with wide letter spacing on
labels, 2 colors plus neutrals (black, bone, a muted earth or metallic accent),
thin lines, large calm photography, no shadows, no gradients.
**Risk**: emptiness without substance. The single photo or the single line of
text must be excellent.

## 4. Bold commercial
**Fits**: promotions, retail, food delivery, marketplaces, mass-market ads.
**Recipe**: very large heavy type (Montserrat 800-900, Unbounded), high-contrast
pair (yellow/black, red/white, blue/white), big price or percentage, product cut
out and oversized, stickers and badges used sparingly, diagonal energy.
**Risk**: shouting everything. Keep one message and one number.

## 5. Neo-brutalist
**Fits**: youth brands, startups, creative studios, events.
**Recipe**: thick black outlines, hard offset shadows (no blur), flat saturated
fills, visible grid, monospace or quirky grotesque accents, deliberately raw.
**Risk**: reads as careless if spacing and alignment are not exact. Not for
finance, medicine or luxury.

## 6. Bento / modular
**Fits**: SaaS feature overviews, product pages, dashboards, summaries.
**Recipe**: grid of rounded cells of different sizes, one large hero cell, each
cell one idea with a mini illustration or number, consistent radius and gap,
subtle surface contrast.
**Risk**: becomes a grid of equal boxes. Vary cell sizes and give one cell real
dominance.

## 7. Soft friendly
**Fits**: kids, family services, clinics, education for beginners, consumer apps.
**Recipe**: rounded typeface (Nunito, Rubik), large radii, pastel base with one
saturated accent, simple rounded illustrations, friendly microcopy.
**Risk**: childish for serious purchases. Pair with a firm dark neutral for text.

## 8. Dark tech
**Fits**: developer tools, AI products, cybersecurity, gaming, automotive.
**Recipe**: near-black tinted background, light text, one neon or electric
accent, fine grid lines or dotted textures, monospace details, glow used on one
element only, product screenshots as heroes.
**Risk**: the most over-used AI-era look. Avoid purple-blue gradients and blobs;
choose an unexpected accent (lime, amber, coral) and real product imagery.

## 9. Warm craft
**Fits**: cafes, bakeries, handmade goods, farms, local food brands.
**Recipe**: warm paper background, deep green, terracotta or brown, a
characterful serif or hand-drawn accent used once, textured photos in natural
light, simple line illustrations, stamps and labels.
**Risk**: cliche rustic. Keep the layout modern and clean.

## 10. Heritage / ornamental
**Fits**: national cuisine, tourism, crafts, cultural events, holiday campaigns.
**Recipe**: a modern layout with one ornamental motif used as a frame, border or
pattern (geometric girih-like patterns, suzani-inspired florals, ceramic
motifs), a palette drawn from traditional materials (deep blue, turquoise, gold,
pomegranate red, cream), contemporary typography.
**Risk**: kitsch when ornament covers everything. Use the motif once, at scale,
and keep the rest minimal. Draw original simplified patterns rather than copying
specific artworks, and treat religious and national symbols with respect.

## 11. Retro pop
**Fits**: fast food, entertainment, events, youth fashion.
**Recipe**: limited palette of 3 flat colors, chunky display type, halftone or
grain texture, simple geometric shapes, playful rotation.
**Risk**: illegible if texture sits over text. Keep text on flat color.

## 12. Data-forward
**Fits**: reports, investor decks, case studies, analytics products.
**Recipe**: big numbers as heroes, clean charts with one highlight color,
tabular figures, restrained palette, clear captions that state the insight.
**Risk**: dull. Give each page one number at dramatic scale.

## 13. How to choose

| If the goal is | Start from |
|---|---|
| Trust and order | Swiss, Editorial, Data-forward |
| Looking expensive | Premium minimal, Editorial |
| Stopping the scroll | Bold commercial, Retro pop, Neo-brutalist |
| Explaining a product | Bento, Swiss, Dark tech |
| Warmth and approachability | Soft friendly, Warm craft |
| Local identity and tradition | Heritage, Warm craft |

Then look at the competitors: if they all use one style, choosing a different
suitable one is the quickest way to be remembered.
