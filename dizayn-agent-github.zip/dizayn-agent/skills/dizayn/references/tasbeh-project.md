# Tasbeh Project Playbook

The home project of this design team: a tasbeh (tasbih) product with a mobile
app and a market (store). Read this before any work on the project. Specific
facts about the brand (name, colors, what exactly is sold) live in the memory
file, not here; this file holds the domain knowledge that stays true.

## Contents
1. What is being designed
2. Audience
3. Respect and accuracy rules
4. Visual direction
5. Typography and Arabic text
6. The app: zikr counter UX
7. The market: store UX
8. App store presence
9. Marketing and content
10. Seasons
11. Common mistakes

## 1. What is being designed

Three connected surfaces that must feel like one brand:

- **The tasbeh itself** (physical beads, a digital counter, or a smart device):
  packaging, inserts, product photography.
- **The app**: zikr counter and whatever surrounds it (history, reminders,
  collections of zikr, pairing with a device if it is smart).
- **The market**: catalog, product pages, checkout, order tracking, inside the
  app or on the web.

Plus the marketing around them: store listing, landing page, Instagram and
Telegram content, ads.

If the memory file does not yet say which of these exist and what the product
is, ask the owner once and record the answer.

## 2. Audience

Practising Muslims of all ages, mainly in Uzbekistan and nearby countries; gift
buyers (for parents, for Ramazon and hayit, for Haj and Umra travellers); and
younger users who want a clean modern tool. Expect a wide age range: older users
need large text and simple flows; younger users expect current design quality.

Motivation is spiritual, not entertainment. The product serves worship, so the
design must feel calm, sincere and trustworthy rather than exciting or
gamified.

## 3. Respect and accuracy rules

These matter more than any aesthetic choice. A mistake here damages trust in
the whole brand.

- **Sacred text is never invented or paraphrased.** Qur'an verses, names of
  Allah, zikr formulas, duas and hadith come from the owner or a source the
  owner has approved, and are copied exactly. Do not write Arabic religious
  text from memory, do not compose translations of verses, and do not state the
  virtues or rewards of a zikr or attribute a saying to the Prophet (peace be
  upon him) unless the owner supplied the text and its source. Where religious
  content is needed and not supplied, leave a clearly marked slot: "[matn
  mutaxassis tomonidan tasdiqlanadi]".
- **Recommend review by a qualified person** (imam, scholar, the owner's
  religious adviser) for every piece of religious content before publication,
  and say so in the handoff.
- **Placement of sacred text**: not on anything that will be stepped on, thrown
  away carelessly or placed in undignified contexts; not cropped mid-word; not
  stretched, mirrored or used as a faint decorative texture behind other
  content; not covered by buttons or price tags.
- **Arabic must render correctly**: right-to-left, joined letters, correct
  diacritics, in a proper Arabic typeface. Broken or disconnected Arabic is
  worse than no Arabic. If correct rendering cannot be verified, use a slot and
  say so.
- **Imagery is modest and dignified.** Prefer hands with beads, the object
  itself, light, architecture, pattern and nature. Avoid depicting prophets or
  companions in any form. Follow the owner's preference on showing people and
  faces, and record that preference in memory.
- **No manipulation.** No fake urgency, guilt-based notifications, streak
  pressure, or rewards that turn worship into a game. Gentle reminders and a
  quiet record of practice are fine; competitive leaderboards and "you lost
  your streak" messages are not. No claims that a product makes worship more
  accepted or brings guaranteed spiritual results.
- **Commerce stays tasteful**, especially around Ramazon and other sacred
  times: offers are presented as service and gift-giving, not aggressive sales.
- Differences of opinion exist between scholars and communities on some
  practices (including counting devices themselves). Stay neutral, follow the
  owner's position, and avoid wording that judges other practices.

## 4. Visual direction

The category is full of the same look: bright green, gold gradients, mosque
silhouettes and clip-art crescents. A calm, modern, well-crafted identity will
stand out and feel more sincere.

Principles:
- **Calm first**: generous space, few elements, soft contrast in backgrounds,
  strong contrast in text. The interface should lower the pulse.
- **Material honesty**: the tasbeh is a tactile object. Bead, cord, tassel,
  wood, stone and light are the natural sources of form and texture.
- **Geometry over illustration**: circles (the bead, the cycle of 33 and 99),
  arcs, and original simplified geometric patterns in the spirit of Islamic
  tile and girih work. Draw original patterns; do not copy specific artworks.
- **One ornament, used once**: a pattern as a frame or background at low
  intensity, never everywhere.

Palette territories to choose from (pick one, record it in memory):

| Territory | Base | Brand | Accent | Feeling |
|---|---|---|---|---|
| Night and light | Deep ink blue #0F1B2D | Soft ivory #F3ECDD | Warm brass #C9A24B | Contemplative, premium |
| Stone and sand | Sand #EFE7DA | Deep olive #4B5A3C | Clay #B5673F | Natural, warm, craft |
| Turquoise heritage | Cream #F7F2E8 | Samarkand blue #1F5F8B | Turquoise #2FA8A0 | Local, architectural |
| Quiet green | Off-white #F6F5F0 | Deep emerald #0F4A3A | Muted gold #BFA05A | Familiar but refined |
| Monochrome | Paper #FAFAF7 | Charcoal #1C1C1A | One accent only | Modern, minimal |

Use gold as a flat muted tone, never as a shiny gradient. Dark mode is not
optional: many people do zikr before dawn and at night, so design a true dark
theme with low glare.

Signature element ideas: a ring of 33 dots that fills as the count advances;
a single bead as the logo mark; an arc that completes a circle; a subtle
eight-fold pattern built from the bead shape.

## 5. Typography and Arabic text

- **Latin and Cyrillic UI**: calm humanist or geometric sans with full Uzbek
  support (Inter, Golos Text, Manrope, Onest). Verify oʻ, gʻ, ў, қ, ғ, ҳ.
- **Arabic**: a proper Naskh for reading text (Amiri, Noto Naskh Arabic,
  Scheherazade New) and, if the owner wants, a display style for headings.
  Arabic needs a larger size than Latin for equal legibility (about 1.3-1.5x)
  and more line height (1.8-2.2) so diacritics do not collide.
- Set Arabic with `dir="rtl"` and `lang="ar"`; never letter-space Arabic; never
  use faux bold or italic on it.
- Typical zikr screen hierarchy: Arabic text (largest), transliteration,
  translation in the user's language, then source if supplied.
- Numbers: the counter numeral is the hero of the app; choose a typeface with
  beautiful clear figures and use tabular figures so the number does not jump
  in width.
- Languages to plan for: Uzbek Latin first, then Uzbek Cyrillic, Russian,
  possibly English and Arabic interface. Layouts must survive long Uzbek words
  and, for an Arabic interface, full right-to-left mirroring.

## 6. The app: zikr counter UX

The main screen has one job: count without making the person look at the
screen.

- **The whole screen is the button.** A very large tap area usable with one
  thumb, eyes closed. No small targets near it that could be hit by accident.
- **Feedback for every count**: haptic tick, optional soft sound, a stronger
  signal at the end of a round (33, 99, 100 or a custom target).
- **The number is huge and clear**; progress within the round is shown as a
  ring or beads filling.
- **Physical controls**: support counting with the volume buttons, and keep the
  screen awake or allow counting with the screen dimmed to save battery.
- **Protection from accidents**: reset and undo need a deliberate action (long
  press or confirm); an undo for the last count is always available.
- **Never lose a count**: save continuously, work fully offline, restore after
  the app is closed.
- **Calm interface**: no ads, banners or pop-ups on the counting screen. Shop
  promotions never interrupt zikr.
- **Presets and custom**: common targets, the owner-approved list of zikr, and
  the ability to add one's own with a target number.
- **History**: a quiet personal record (today, week, total) presented as
  information, not competition. Private by default.
- **Reminders**: gentle, user-chosen times, respectful wording, easy to turn
  off.
- **Accessibility**: large-text mode, high contrast, simple mode for older
  users, left-hand and right-hand comfort.
- **If the tasbeh is a smart device**: pairing flow in 3 clear steps with
  illustrations, connection and battery status always visible, sync state
  shown plainly, a manual counting fallback when the device is not connected.

Other screens to design: onboarding (3 screens at most, skippable), zikr
library, zikr detail, statistics, settings, and the market entry point.

## 7. The market: store UX

Follow the e-commerce patterns in `ux-product.md`, with these specifics:

- **Product attributes buyers care about**: material (wood type, stone, glass,
  resin), bead count (33, 99, other), bead size in mm, length, weight, tassel
  or finishing, color, origin, whether it is handmade, gift box included.
- **Photography**: macro shots showing material and finish, the tasbeh in a
  hand for scale, the full length laid out, the packaging. Consistent neutral
  background and soft natural light across the catalog. Real product photos
  only; never generated images for items being sold.
- **Filters**: material, bead count, price, color, purpose (gift, daily use,
  travel).
- **Gift flow**: gift wrapping, a card with a message, delivery to another
  address, sets (tasbeh with prayer mat, perfume or a book if the shop sells
  them).
- **Trust**: clear delivery times and cost, payment by local methods, returns,
  real contacts, honest descriptions of materials (do not call resin
  "amber").
- **Catalog tone**: quiet and respectful; product names descriptive; prices
  clear; no shouting badges.
- **Link between app and market**: the market has its own tab or section;
  product suggestions appear in appropriate places (profile, after a
  milestone summary at most), never on the counting screen.

## 8. App store presence

- **Icon**: one simple shape (a bead, a ring of beads, an arc), 2 colors,
  recognizable at small size, no text, no photo. Test on light and dark
  wallpapers.
- **Screenshots**: 5-8 frames telling a story: 1) the core benefit with the
  counter screen, 2) zikr library, 3) history, 4) reminders, 5) the market,
  6) dark mode. One short caption per frame in large type, in each store
  language. Show the real interface.
- **Google Play assets (verify current requirements before upload)**: icon
  512 x 512, feature graphic 1024 x 500, phone screenshots in 9:16 such as
  1080 x 1920.
- **App Store**: screenshot sizes depend on current device classes; check the
  current specification before export.
- **Listing text**: plain description of what the app does; no religious
  promises; accurate category and content rating.

## 9. Marketing and content

- **Message hierarchy**: what it is (a tasbeh and an app that counts for you),
  the practical benefit (never lose count, a record of practice, reminders),
  then the quality of the object and the gift occasion.
- **Tone**: sincere, warm, calm. Short sentences. "Siz" form unless the owner
  prefers otherwise.
- **Content pillars** (confirm with the owner): product and craft, how the app
  works, gift ideas, customer stories with permission, and religious reminders
  only from approved sources.
- **Ads**: show the object in a hand and the screen beside it; one line of
  benefit; contact route. Avoid any wording that sells spiritual outcomes.
- **Landing page**: hero with the tasbeh and the app together, how it works in
  3 steps, features, materials and craft, market preview, download buttons,
  delivery and contacts.
- **Packaging**: the unboxing is part of the gift; keep it elegant and avoid
  printing sacred text on parts that will be thrown away.

## 10. Seasons

Plan campaigns for Ramazon, Ramazon hayiti, Qurbon hayiti, the Haj and Umra
seasons, Juma, and gift moments such as weddings and visits to parents. Dates
follow the lunar calendar and local announcements, so confirm them each year
rather than assuming. Seasonal visuals stay within the brand system: change the
accent and motif, not the whole identity.

## 11. Common mistakes

- Bright green plus shiny gold plus a mosque silhouette: the category cliche.
- Arabic text rendered broken, disconnected or in a Latin font.
- Unverified hadith or virtues quoted on posts.
- Small counter button, accidental resets, lost counts.
- Shop banners interrupting zikr.
- Gamification that turns worship into competition.
- Crowded screens for a product whose whole purpose is calm.
- Generated or misleading product photos.
