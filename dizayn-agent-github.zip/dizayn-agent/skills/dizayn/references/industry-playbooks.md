# Industry Playbooks

Starting points per industry: what the customer needs to see, what tends to work
visually, and the usual mistakes. These are working heuristics, not research
findings; adjust to the specific brand, audience and competitors.

## Contents
1. Retail shops and online stores
2. Bookstores and education products
3. Restaurants, cafes, food delivery
4. Clinics, dentistry, pharmacy
5. Education centers and courses
6. B2B, IT services, SaaS
7. Beauty and wellness
8. Construction, real estate, furniture
9. Auto and services
10. Personal brand / expert
11. Events and seasonal campaigns

## 1. Retail shops and online stores
**Customer needs**: price, availability, delivery, how to order, proof the shop
is real.
**Works**: product as the hero on a clean background, large price, clear
category navigation, badges for delivery and payment options, consistent product
photo style.
**Mistakes**: many products on one banner, tiny prices, inconsistent photos,
no delivery information near the buy button.
**Key screens**: catalog grid, product page, cart, order confirmation.

## 2. Bookstores and education products
**Customer needs**: what the book or product gives them, level or age, price,
delivery, reviews.
**Works**: editorial style, warm paper tones, ink blue or deep green, book
covers shown large and straight or at a consistent angle, curated shelves
("Tadbirkorlar uchun 5 kitob"), quotes from the book.
**Mistakes**: covers lost among decoration, more than one accent color competing
with colorful covers. Keep the interface neutral so the covers carry the color.

## 3. Restaurants, cafes, food delivery
**Customer needs**: appetizing photo, price, location, working hours, how to
order.
**Works**: large well-lit food photography, warm colors, dark or cream
backgrounds, short menu groups with prices aligned, one hero dish per post.
**Mistakes**: cold blue tones on food, photos with harsh flash, long ingredient
text over the image, missing address or delivery contact.
**Formats**: menu (print and QR), story with daily offer, delivery banner.

## 4. Clinics, dentistry, pharmacy
**Customer needs**: trust, the doctor's qualification, price range, how to book,
cleanliness.
**Works**: calm palette (teal, soft blue, white, warm grey), real photos of
doctors and the clinic, plain language, clear booking CTA, licenses mentioned.
**Mistakes**: frightening imagery, red as a main color, stock smiling models,
promises of guaranteed results. Health claims must be accurate and compliant
with local advertising rules; recommend the clinic confirm wording.

## 5. Education centers and courses
**Customer needs**: the result after the course, the teacher, schedule, price,
graduates' outcomes.
**Works**: results in numbers the center can prove, teacher's face, program as a
timeline, a strong first-lesson or trial CTA, energetic but orderly style.
**Mistakes**: lists of topics instead of outcomes, group photos nobody can read,
unverifiable guarantees ("100% natija").

## 6. B2B, IT services, SaaS
**Customer needs**: what it does in one sentence, proof it works for businesses
like theirs, price logic, how fast it starts, support.
**Works**: Swiss or bento style, real product screenshots, a short demo, case
studies with numbers, a clear step-by-step of onboarding, demo or consultation
CTA with a Telegram route.
**Mistakes**: abstract 3D shapes instead of the product, jargon, feature lists
without benefits, no prices and no reason given.
**Key sections**: hero with screenshot, "who it is for", before/after of the
client's process, integrations, pricing, FAQ.

## 7. Beauty and wellness
**Customer needs**: results (before/after), master's skill, price, location,
booking.
**Works**: premium minimal, soft neutral palette with one accent, real work
photos in consistent light and crop, simple price list, booking button in every
post.
**Mistakes**: script fonts that cannot be read, gold gradients, heavy filters,
collages of ten photos.

## 8. Construction, real estate, furniture
**Customer needs**: finished results, timelines, price per unit, guarantees,
company reliability.
**Works**: large photography or renders, strong grid, solid dark neutrals with
one accent, numbers (m², term, years on market), plans and process steps.
**Mistakes**: renders presented as finished photos without saying so, crowded
contact blocks, low-resolution images at large size.

## 9. Auto and services
**Customer needs**: price, time, guarantee, location, before/after.
**Works**: bold commercial or dark tech, big service price "dan boshlab", clear
list of what is included, map and working hours.
**Mistakes**: flames, chrome effects, ten services on one banner.

## 10. Personal brand / expert
**Customer needs**: who this person is, why listen, what they will learn.
**Works**: one strong portrait style used consistently, editorial type, a
recognizable color, quotes and short theses in large type, a consistent cover
system for Reels.
**Mistakes**: different style in every post, text too long for a frame, the
face covered by text.

## 11. Events and seasonal campaigns
**Customer needs**: what, when, where, how to join, why it matters.
**Works**: date and place as the largest elements after the title, one key
visual repeated across all formats, countdown stories.
**Seasonal notes**: Navro'z suits spring greens, florals and light; Ramazon
suits calm deep tones, crescent and lantern motifs used with restraint and
respect; Yangi yil suits winter palettes; Mustaqillik kuni uses national colors
with care. Keep commercial offers tasteful around religious occasions.
