# Brend profili (shablon)

Fill this once and attach it to future design requests (or keep it in the
project's files). When it is present, every design must follow it.

```
BREND: 
Faoliyat (1 gap): 
Auditoriya: 
Pozitsiya (1 gap): 
Xarakter (3 so'z): 
Ovoz ohangi (siz/sen, rasmiy/do'stona): 

LOGO: (fayl nomi yoki tavsif; qaysi versiya qayerda ishlatiladi)

RANGLAR
- Asosiy:      #______  (roli: )
- Aksent:      #______  (faqat CTA va urg'u uchun)
- Fon:         #______
- Matn:        #______
- Qo'shimcha:  #______

SHRIFTLAR
- Sarlavha: 
- Matn: 

USLUB
- Asosiy uslub (masalan: Swiss, Premium minimal): 
- Imzo element: 
- Burchak radiusi: 
- Foto uslubi: 
- Nima qilinmaydi: 

KONTAKTLAR (reklama va CTA uchun)
- Sayt: 
- Telegram: 
- Telefon: 
- Instagram: 
- Manzil / ish vaqti: 

TILLAR: (o'zbek lotin / kirill / rus)

DOIMIY MATNLAR
- Shior: 
- Asosiy taklif: 
- Tasdiqlangan raqamlar va dalillar: 
```

Rules for the agent:
- Use only the contacts listed here on designs.
- Use only numbers and proof listed under "Tasdiqlangan raqamlar"; anything
  else is a placeholder to confirm.
- If a request conflicts with the profile, follow the request and mention the
  difference in one line.
