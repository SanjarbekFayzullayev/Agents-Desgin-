# Layout and Composition

## Contents
1. Hierarchy
2. Grids and alignment
3. Spacing
4. Composition techniques
5. UI components
6. Marketing page sections
7. Dashboards and data screens
8. Responsive behavior
9. Motion

## 1. Hierarchy

A viewer should read the piece in the order you intend. Assign every element a
rank (1 = seen first) and make the ranks visibly different.

Tools, in order of strength: size, weight, color/contrast, position (top-left and
center are read first), white space around the element, and isolation.

- Exactly one rank-1 element per screen or frame.
- Rank 2 supports it (subhead, key visual, price). Rank 3 is detail.
- De-emphasize instead of emphasizing everything: lowering secondary text to a
  softer neutral often does more than making the headline bigger.
- One primary button per view. Secondary actions are outlined or text links.

## 2. Grids and alignment

- Web: 12-column grid, max content width 1120-1280px, gutters 24-32px, side
  padding 20-24px on mobile and 48-80px on desktop.
- Social and posters: divide the canvas into a simple grid (for example 6x6 or
  4x5) and snap edges to it. Keep outer margins of 6-8% of the short side
  (64-90px on a 1080px canvas).
- Every element should share at least one edge with another element. Count the
  distinct left edges on the page; fewer is better.
- Prefer left alignment with a strong vertical axis. Centered layouts suit short,
  formal or symmetrical pieces (invitations, quotes, logos).
- Break the grid on purpose, once, for the signature element (an image bleeding
  off the edge, a numeral overlapping two sections). Breaking it everywhere is
  just mess.

## 3. Spacing

Use a scale based on 4 or 8: `4 / 8 / 12 / 16 / 24 / 32 / 48 / 64 / 96 / 128`.

- Proximity is meaning: space inside a group must be clearly smaller than space
  between groups (a ratio of at least 1:2).
- Label-to-field gap < field-to-field gap. Heading sits closer to the text it
  introduces than to the text above it.
- Section padding on landing pages: 96-128px desktop, 56-72px mobile.
- When a design feels cheap or crowded, add space before changing anything else.
  Generous margins are the fastest route to a premium look.
- Padding inside cards: at least 24px on desktop; card padding should be equal to
  or greater than the gap between elements inside it.

## 4. Composition techniques

- **Scale contrast**: pair something very large with something small. A huge
  numeral, word or product cropped by the frame creates drama.
- **Asymmetry**: place the main mass off-center (rule of thirds) and balance it
  with empty space or a small counterweight.
- **Layering and overlap**: let an image overlap a color block, or text overlap
  an image edge, to create depth without shadows.
- **Direction**: faces, arrows, diagonals and product angles should point toward
  the headline or CTA, not out of the frame.
- **Rhythm**: repeat a shape, a color or an interval, then interrupt it once.
- **Framing**: thick rules, corner marks, a border or a color band give structure
  to text-only layouts.
- **Negative space**: empty areas are active elements. Do not fill them.
- **Consistent geometry**: pick one radius logic (sharp 0-2px, soft 8-12px, or
  round 20px+ / pills) and one line weight, and use them everywhere.

## 5. UI components

- **Buttons**: height 44-52px, horizontal padding 20-28px, weight 600, label is a
  verb + result ("Demo olish", "Narxni bilish"). States: default, hover, active,
  focus (visible ring), disabled, loading.
- **Inputs**: label always visible above the field, 44-48px height, clear focus
  state, error text below in plain language. Ask for the minimum number of
  fields; each extra field costs conversions.
- **Cards**: one clear purpose each. Vary size and emphasis (a featured card
  larger than the rest) instead of three identical boxes. Border or shadow or
  background tint; rarely all three.
- **Navigation**: 4-6 items, current item marked, primary CTA on the right. On
  mobile, a bottom bar for apps or a simple menu for sites.
- **Icons**: one set, one stroke weight, sized on the grid (16/20/24). Draw simple
  inline SVG icons; do not use emoji as icons in finished work.
- **Tables**: left-align text, right-align numbers, generous row height
  (48-56px), subtle row dividers, sticky header, no heavy grid lines.
- **Empty, loading and error states** are part of the design. Include them for
  product UI.
- **Touch targets**: at least 44x44px with 8px between them.
- **Shadows**: soft, large blur, low opacity, slightly tinted (for example
  `0 12px 32px -12px rgba(16,24,40,.18)`). One or two elevation levels only.

## 6. Marketing page sections

Vary the layout section to section so the page has rhythm: full-bleed color,
then a split layout, then a grid, then a single centered statement.

- **Hero**: concrete headline, one supporting sentence, one primary CTA, and a
  visual that shows the actual product or result. Split (text left, visual right)
  usually beats centered-on-gradient.
- **Proof strip**: real numbers, logos or ratings directly under the hero.
- **Problem / solution**: speak in the customer's words; show before and after.
- **Features as benefits**: alternate image/text rows or use a bento grid with
  one large cell; avoid the 3-identical-cards row.
- **How it works**: 3-4 numbered steps with large numerals.
- **Pricing**: 2-3 plans, the recommended one visually dominant, differences easy
  to scan.
- **Objections / FAQ**: 5-7 real questions.
- **Final CTA**: repeat the offer on a strong color band with the contact route.

## 7. Dashboards and data screens

- Lead with the 3-5 numbers that drive decisions, as large stat tiles with a
  comparison (vs last period) and direction.
- One chart answers one question; title the chart with the insight when known.
- Use one hue for data with a single highlight color; reserve red/green for
  bad/good. Label directly instead of relying on legends where possible.
- Dense is fine if aligned: consistent tile sizes, shared baselines, muted
  chrome, strong numbers.

## 8. Responsive behavior

- Design the mobile layout deliberately (most traffic from Instagram and Telegram
  links is mobile): single column, 16-18px body, CTA reachable by thumb, sticky
  bottom CTA on long pages.
- Use fluid sizes (`clamp()`), CSS grid with `auto-fit`/`minmax`, and test at
  360px, 768px and 1280px+.
- Fixed-size artboards are scaled with CSS `transform: scale()` or `zoom` to fit
  the viewport while keeping exact export dimensions.

## 9. Motion

Use motion to guide attention, never to decorate. Entrance fades and slides of
12-24px, 200-400ms, ease-out; staggered reveals for lists; hover feedback within
150ms. Respect `prefers-reduced-motion`. One memorable moment (a hero reveal, a
counter counting up) is better than motion on everything.
