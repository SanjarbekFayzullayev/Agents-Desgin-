# Design Critique Rubric

Use this when the user shares an existing design (screenshot, link, file) and asks
for a review, or when grading your own draft against a high bar.

## How to review

1. Look at the whole piece for a few seconds first and note the honest first
   impression: what did you see first, what is it about, how does it feel?
2. Identify the goal and audience (ask if unknowable; otherwise state the
   assumption).
3. Score each criterion 1-5 and note evidence: point at specific elements, not
   general impressions.
4. Prioritize. Three fixes that change the result matter more than twenty notes.
5. If useful, produce a redesigned version applying the top fixes, so the user
   sees the difference rather than reading about it.

Be direct and specific, and respectful of the work. "The headline and the price
are the same size, so the eye has nowhere to land; make the price 2x larger" is
useful. "Needs more pop" is not. Do not inflate scores to be kind: an honest 2
with a clear fix helps the owner more than a polite 4.

## Criteria

| # | Criterion | 1 (weak) | 5 (excellent) |
|---|---|---|---|
| 1 | Clarity of message | Unclear what it is or what to do | Understood in 3 seconds |
| 2 | Visual hierarchy | Everything competes | Obvious 1-2-3 reading order |
| 3 | Typography | Many fonts, poor sizes, hard to read | Purposeful pairing, clear scale, comfortable reading |
| 4 | Color | Random or clashing, weak contrast | Disciplined palette with roles, accessible contrast |
| 5 | Layout and spacing | Crowded, misaligned | Grid-aligned, consistent rhythm, room to breathe |
| 6 | Brand fit and distinctiveness | Could belong to anyone | Recognizable and right for the audience |
| 7 | Conversion readiness | No clear action or proof | Strong offer, visible CTA, proof nearby |
| 8 | Craft and consistency | Inconsistent radii, icons, image quality | Polished, consistent details |
| 9 | Format and technical fit | Wrong size, cut off, unreadable on mobile | Correct specs, safe zones, responsive |

Criterion 7 applies to selling pieces; skip it for purely informational or
internal work and say so.

Total: average of applicable scores. Rough reading: below 2.5 needs a redesign;
2.5-3.5 solid base with clear fixes; 3.5-4.5 professional; above 4.5 exceptional.

## Report format

```
## Umumiy baho: X.X / 5
Birinchi taassurot: (1-2 sentences)

## Kuchli tomonlar
- (2-3 specific things worth keeping)

## Asosiy muammolar (ta'sir bo'yicha tartibda)
1. Muammo - nima uchun zarar qiladi - aniq tuzatish
2. ...
3. ...

## Baholar
| Mezon | Baho | Izoh |

## Tez tuzatishlar (30 daqiqada)
- ...

## Keyingi qadam
(offer to produce the improved version)
```

Write the report in the user's language. Keep it to one screen unless the user
asks for depth.

## Common findings and their fixes

- **No focal point** -> enlarge one element 2-3x, reduce the rest.
- **Too many messages** -> keep one, move the rest to a carousel or caption.
- **Looks cheap** -> cut colors to 2 + neutrals, add margin, reduce effects,
  use one refined typeface.
- **Hard to read** -> raise contrast, increase size, shorten lines, left-align.
- **Feels dated** -> remove bevels, heavy shadows and stock clip-art; adopt a
  clean grid and a current typeface.
- **Inconsistent series** -> build a template: fixed margins, logo position,
  type sizes and color logic.
- **Weak CTA** -> action verb + result, accent color, more space around it,
  repeat near the end.
- **Text over busy photo** -> add a scrim or panel, or move the text to a calm
  area.
