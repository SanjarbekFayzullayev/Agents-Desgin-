# Typography and Color

## Contents
1. Choosing typefaces
2. Language support (Uzbek, Russian)
3. Type scale and setting
4. Building a palette
5. Color by industry and mood
6. Dark mode and color on photos

## 1. Choosing typefaces

Type carries most of the personality of a design. Choose by the feeling the brand
needs, then check language support (section 2) before committing.

| Feeling | Display (headlines) | Text (body) |
|---|---|---|
| Modern, tech, SaaS | Inter Tight, Manrope, Onest, Geologica | Inter, Golos Text |
| Bold, energetic, sales | Unbounded, Dela Gothic One, Montserrat 800-900 | Inter, Roboto |
| Premium, editorial | Playfair Display, Cormorant, Lora | Inter, Source Sans 3 |
| Friendly, retail, food | Nunito, Rubik, Comfortaa (sparingly) | Nunito Sans, Rubik |
| Corporate, finance, legal | IBM Plex Sans, PT Serif, Source Serif 4 | IBM Plex Sans, PT Sans |
| Technical, data | JetBrains Mono (accents), IBM Plex Mono | Inter, IBM Plex Sans |

Rules of thumb:
- Two families at most: one with character for headlines, one neutral for text.
  A single family in several weights is often the most elegant choice.
- Pair by contrast (serif + sans, wide + normal), not by similarity. Two similar
  sans-serifs look like a mistake.
- Avoid shipping the system default look. If the result could be any website, the
  typeface choice has not been made yet.
- Load web fonts from Google Fonts with `display=swap` and include a fallback
  stack. If the environment may block external requests, pick a strong system
  stack and rely on weight, size and spacing for character.

## 2. Language support (Uzbek, Russian)

Many clients publish in Uzbek Latin, Uzbek Cyrillic and Russian. A beautiful font
that drops to a fallback on one letter ruins the piece.

- **Uzbek Latin**: the letters oʻ and gʻ use the modifier letter turned comma
  (U+02BB), and the tutuq belgisi uses U+02BC. In practice people type a straight
  apostrophe (') or a backtick. In finished designs, replace these with the proper
  character ʻ (U+02BB) when the font has it; otherwise use the typographic
  apostrophe ‘ (U+2018), which looks nearly identical. Never leave a backtick.
- **Uzbek Cyrillic** needs ў, қ, ғ, ҳ (extended Cyrillic). Many display fonts with
  "Cyrillic" support lack these.
- **Russian** needs basic Cyrillic only.
- Fonts that generally cover all three: Inter, Roboto, Noto Sans / Noto Serif,
  Golos Text, IBM Plex Sans, PT Sans / PT Serif, Montserrat, Manrope, Rubik.
  Support changes between font versions, so always test the actual string
  "Oʻzbekiston gʻoya ўқитувчи ҳақида" in the rendered output and switch fonts if
  any glyph falls back.
- Uzbek words are long and sentences run about 15-25% longer than English. Leave
  room: avoid tight fixed-width buttons, and prefer slightly narrower or condensed
  display faces for long headlines.

## 3. Type scale and setting

Use a modular scale rather than arbitrary sizes. Web default (ratio ~1.25):

`12 / 14 / 16 / 20 / 24 / 32 / 40 / 56 / 72`

For social and ad formats on a 1080px canvas, think bigger: body 32-40px,
subhead 44-56px, headline 80-140px. Text under 28px on a 1080px canvas is
unreadable on a phone.

- Hierarchy needs real contrast: headline at least 2x body on web, 3-5x on
  posters and social.
- Line height: body 1.45-1.6; headlines 1.0-1.15; all-caps labels 1.2.
- Letter spacing: large headlines -1% to -3%; all-caps labels +6% to +12%;
  body 0.
- Line length: 45-75 characters for body text. Constrain with `max-width: 65ch`.
- Weights: use two or three with clear gaps (400 / 600 / 800). Avoid weights
  under 400 below 18px.
- Headlines: break lines by meaning, never leave a single short word alone on the
  last line (`text-wrap: balance` helps on web).
- Numbers are design material. Prices, percentages and deadlines deserve the
  largest size on the page; use tabular figures in tables.
- Left-align body text. Center only short blocks (up to about 3 lines).

## 4. Building a palette

Work with roles, not a list of pretty colors.

- **60 / 30 / 10**: about 60% neutral base (background), 30% secondary (surfaces,
  dark text blocks), 10% accent (CTA, key highlights). The accent works only
  because it is rare.
- One brand hue + one accent + a neutral ramp is enough for almost everything.
- Neutral ramp: 9-10 steps from near-white to near-black, tinted slightly toward
  the brand hue (pure grey looks dead next to a strong color). Avoid pure #000 and
  #FFF for large areas; use something like #0E1116 and #FAFAF7.
- Accent choice: complementary or split-complementary to the brand hue for energy;
  analogous for calm.
- Build tints and shades by changing lightness and slightly shifting saturation,
  ideally in OKLCH or HSL, so steps feel even.
- Semantic colors (success, warning, error) are separate from brand colors and
  used only for their meaning.
- If the user gives a brand color, keep it exact, and derive everything else
  around it.
- Verify contrast for every text/background pair with `scripts/contrast.py`.

## 5. Color by industry and mood

Starting points, not rules. The competitive context matters more: if every
competitor is blue, a different hue is an advantage.

| Context | Tends to work | Notes |
|---|---|---|
| Finance, B2B, IT services | Deep navy, graphite, one sharp accent (lime, orange, electric blue) | Signals stability; accent adds modernity |
| Medical, pharmacy | Clean teal, soft blue, white, warm grey | Avoid alarming reds outside warnings |
| Food, restaurants | Warm reds, oranges, cream, deep green | Appetite colors; avoid cold blue on food |
| Education, books | Warm ivory, ink blue, terracotta, forest green | Calm, readable, trustworthy |
| Fashion, beauty, premium | Black, bone, muted earth tones, metallic accent used sparingly | Space and restraint read as expensive |
| Kids, entertainment | Saturated primaries with plenty of white | Keep to 3 hues to avoid chaos |
| Sales, promotions | High-contrast pairs: yellow/black, red/white | Urgency; use for offers, not whole brands |
| Eco, agriculture | Greens with earthy neutrals | Avoid neon green; pair with warm tones |

Premium look = fewer colors, lower saturation, more space. Mass-market energy =
higher saturation, bigger type, stronger contrast.

## 6. Dark mode and color on photos

- Dark backgrounds: use a dark tinted neutral (not pure black), lower the
  saturation of accents slightly, and express elevation with lighter surfaces
  rather than shadows.
- Text on photos is the most common failure. Use one of: a solid color panel,
  a gradient scrim (at least 50-70% dark behind the text), a duotone treatment of
  the photo, or place text in a genuinely empty area. Check contrast against the
  lightest part of the area behind the text.
