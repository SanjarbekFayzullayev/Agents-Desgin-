# Worked Examples

Short examples of turning a vague request into a strong creative direction.
They show the reasoning; do not reuse the palettes or headlines as templates.
All businesses and figures here are invented for illustration.

## Example 1: Instagram offer post for a bookstore

**Request**: "Kitob do'konimiz uchun aksiya posti, 3 ta kitob olsa 1 tasi
sovg'a."

**Decisions**
- Viewer: readers scrolling Instagram; 1-2 seconds of attention.
- One thing: buy three, get one free.
- Feeling: warm, intelligent.

**Direction**
- Concept: "3 + 1" as a giant typographic equation made of book spines.
- Style base: Editorial with a bold commercial numeral.
- Palette: paper #F6F1E7 (base), ink #1E2A44 (text), terracotta #D2562F
  (accent, only on "+1").
- Type: PT Serif Bold for the numeral, Inter for details.
- Signature: four vertical bars as book spines, the fourth in terracotta.

**Layout (1080 x 1350)**: margins 80px. "3+1" occupies the upper 55% at about
420px. Below: "Uchta kitob oling, to'rtinchisi sovg'a" at 56px, deadline at
36px, contact strip at the bottom with site and Telegram.

**Why it works**: one message, a number as the hero, a single accent color that
points at the gift.

## Example 2: Landing page for a shop automation SaaS

**Request**: "Do'konlar uchun onlayn market va kassa tizimimizga landing kerak."

**Decisions**
- Viewer: shop owner on a phone, came from an Instagram ad, skeptical.
- One thing: you can sell online and at the counter from one system, set up
  for you.
- Feeling: reliable, simple.

**Direction**
- Concept: "Bitta tizim, ikki savdo" shown as one product screen splitting into
  a storefront and a cash register.
- Style base: Swiss with bento feature blocks.
- Palette: off-white #FAFAF7, graphite #15181D, green #0E7C4A (brand), amber
  #FFB020 (CTA only).
- Type: Onest for headlines, Inter for text.
- Signature: a thin split line running down the page that divides "onlayn" and
  "do'konda" content.

**Structure**: hero with a real product screenshot and "Demo ko'rish" button
plus a Telegram button; proof strip (number of shops connected - placeholder to
confirm); three pains in the owner's words; how the system solves each, with
screens; onboarding in 4 steps with days; one named client case (placeholder
until supplied); pricing; FAQ; final CTA.

**Headline options**: "Do'koningizni 7 kunda onlayn savdoga ulaymiz" /
"Kassa va onlayn market - bitta tizimda". The time frame is a placeholder the
owner must confirm.

## Example 3: "Make it look more expensive"

**Request**: a screenshot of a beauty salon price list with five colors, a
script font, gold gradient and tight spacing.

**Diagnosis (top 3)**
1. Five colors compete; nothing reads as premium.
2. Script font is hard to read at small sizes.
3. No margins; lines touch the edges.

**Moves**
- Palette cut to bone #F4EFE9, charcoal #24211F and one muted rose #B9857A.
- Script replaced by a refined serif for headings and a light sans for prices.
- Margins tripled; services grouped under 4 headings; prices right-aligned in a
  column with dotted leaders removed.
- Gold gradient removed; a single thin rule under each group heading.

**Explanation to the owner**: "Qimmat ko'rinish - bu kamroq rang, ko'proq bo'sh
joy va o'qilishi oson shrift. Uchta narsani o'zgartirdim: ..."

## Example 4: Logo for an IT service company

**Request**: "Kompaniyamizga logo kerak, biz biznes muammolarini tizim bilan
hal qilamiz."

**Strategy in brief**: audience - small business owners; promise - order instead
of chaos; personality - reliable, clear, modern.

**Three routes**
1. Wordmark: the name in a sturdy grotesque with one letter resolved into a
   check mark shape.
2. Monogram: initials built from two interlocking blocks, suggesting pieces
   fitting together.
3. Symbol + wordmark: a tangled line that becomes a straight line, beside the
   name.

**Recommendation**: route 3 tells the story (chaos to order) and gives a symbol
usable as an avatar. Trade-off: slightly more complex at 16px, so a simplified
icon version is supplied.

**Deliverables**: SVG set, palette, two typefaces, avatar, business card and
presentation title slide mock-ups.

## Example 5: Carousel for an expert's personal brand

**Request**: "AI agentlar haqida karusel post kerak."

**Direction**
- Concept: each slide is a numbered "mistake" card.
- Style base: Dark tech without the cliches: near-black #0F1113, off-white
  text, lime #C6F432 accent.
- Type: Unbounded for numerals, Inter for text.
- Signature: a lime corner bracket that moves one step along the frame on each
  slide as a progress marker.

**Sequence**: 1) hook "Biznesga AI ulashda 5 xato"; 2) why it costs money;
3-7) one mistake per slide with a huge numeral and 20 words; 8) checklist;
9) CTA to the Telegram channel.

## Patterns across the examples

- The concept can be said in one sentence.
- One element is dramatically larger than everything else.
- The accent color appears in one or two places only.
- Unverified facts are marked as placeholders rather than invented.
- The explanation to the owner is three sentences in plain language.
