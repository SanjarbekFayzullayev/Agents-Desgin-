# Brand Strategy for Small and Medium Businesses

Design expresses a decision about who the brand is for and what it stands for.
This file is the method for making that decision quickly and concretely.

## Contents
1. Questions that matter
2. Audience
3. Competitor scan
4. Positioning
5. Personality and voice
6. From strategy to visuals
7. Naming and slogans
8. Identity system
9. Rebranding

## 1. Questions that matter

Get answers (or state assumptions) for:

- What do you sell, and at what price level relative to competitors?
- Who buys most often, and who do you wish bought more?
- Why do customers choose you now? What do they say in their own words?
- Who else do they consider?
- What can you prove (numbers, years, cases, guarantees)?
- Where does the customer meet the brand (Instagram, shop, site, referral)?

Three good answers are enough to start. Do not block work on a long interview.

## 2. Audience

Describe 1-2 segments by situation, not demographics alone:

- Who: role and context ("2-3 filialli do'kon egasi, hisobni Excelda yuritadi").
- Trigger: what happened that made them look for a solution.
- Fear: what could go wrong if they choose badly.
- Alternatives: what they compare with, including doing nothing.
- Proof they need: what would convince them.
- Language: the words they use for the problem.

## 3. Competitor scan

List 3-5 alternatives. For each note: main promise, price level, colors, type
style, imagery, tone. Then find the pattern (what everyone does) and the gap
(what nobody claims or shows). Use real research when a search tool exists;
otherwise mark the scan as assumption-based.

## 4. Positioning

Formula: "[Auditoriya] uchun [brend] - bu [kategoriya], u [asosiy foyda] beradi,
chunki [ishonch sababi]."

A strong position is:
- **Specific**: names an audience and a result.
- **True**: the business can deliver and prove it.
- **Different**: competitors cannot say the same sentence.
- **Relevant**: about what the customer cares about, not what the company is
  proud of.

Routes to difference: a niche audience, speed, a guarantee, a method, a price
model, service level, local knowledge, a measurable result. "Quality and good
prices" is not a position.

## 5. Personality and voice

Pick 3 traits, each with a boundary: "ishonchli, lekin zerikarli emas", "jasur,
lekin qo'pol emas", "sodda, lekin arzon emas".

Voice guide in three lines:
- How we address the customer (siz/sen, formal/friendly).
- What we always do (concrete numbers, short sentences, plain words).
- What we never do (jargon, pressure, empty superlatives).

Add 3 do/don't phrase pairs so writers can copy the tone.

## 6. From strategy to visuals

| Trait | Color | Type | Shape | Imagery |
|---|---|---|---|---|
| Trustworthy | Deep blue, navy, green, restrained | Sturdy sans or classic serif | Straight, stable, moderate radius | Real people, clear light |
| Bold | Saturated, high contrast | Heavy, wide, tight | Diagonals, hard edges | Close crops, action |
| Premium | Few, muted, dark or bone | Refined serif or light sans, spaced labels | Thin lines, lots of space | Calm, large, minimal |
| Friendly | Warm, bright, soft | Rounded | Large radii | Smiles, everyday scenes |
| Technical | Dark neutrals, one electric accent | Grotesque plus mono details | Grids, fine lines | Product, interface, data |
| Natural | Greens, earth tones | Humanist sans or soft serif | Organic, textured | Natural light, materials |

Choose a color territory that stands apart from the competitor pattern found in
section 3.

## 7. Naming and slogans

**Routes**: descriptive, suggestive, invented, founder or place, compound.

**Screen each name**:
- Short and easy to say aloud; easy to spell after hearing once.
- Works in Latin and Cyrillic; no bad meaning in Uzbek or Russian.
- Distinct from competitors and from famous brands.
- Free as a .uz domain and as Instagram and Telegram handles (to be checked).
- Registrable as a trademark (requires an official search; advise a specialist).

Present 8-10 options across routes, shortlist 3 with reasons, and state clearly
that availability and legal clearance are not verified.

**Slogan**: 2-6 words stating the benefit or attitude, natural when spoken,
unusable by a competitor without changes. Offer rational, emotional and bold
versions.

## 8. Identity system

A brand is a system, not a logo:

- Logo family: primary, horizontal, stacked, icon, one-color, reversed.
- Palette with roles; typography with usage; shape language; icon style; photo
  style; patterns or signature element; voice.
- Rules: clear space, minimum sizes, misuse examples.
- Proof: applications on the touchpoints this business really has.

The best identities are simple enough for a non-designer to apply correctly.

## 9. Rebranding

Before changing anything, list what customers already recognize (a color, a
shape, a name) and keep or evolve it. Change what causes problems: illegibility,
dated effects, inconsistency, confusion with competitors. Show old and new side
by side on the same applications, and plan the rollout: profiles, signage,
packaging, documents, in order of visibility and cost.
