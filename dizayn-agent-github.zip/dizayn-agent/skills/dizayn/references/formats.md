# Formats: sizes, safe zones and rules

Platform specifications change. The sizes below are widely used working
standards; if the user needs guaranteed-current specs for a paid placement,
verify with a web search when one is available.

## Contents
1. Social media
2. Ad creatives
3. Web
4. Presentations
5. Print
6. Logo and brand identity
7. Export notes

## 1. Social media

| Format | Size (px) | Ratio | Notes |
|---|---|---|---|
| Instagram feed portrait | 1080 x 1350 | 4:5 | Default choice; takes the most feed space |
| Instagram square | 1080 x 1080 | 1:1 | Grid crops to center; keep key content central |
| Instagram Story / Reels cover | 1080 x 1920 | 9:16 | See safe zones below |
| Instagram carousel | 1080 x 1350 per slide | 4:5 | Up to 20 slides; 5-8 works best |
| Telegram post image | 1280 x 720 or 1080 x 1080 | 16:9 / 1:1 | Wide images show small in chat; square or 4:5 reads better |
| YouTube thumbnail | 1280 x 720 | 16:9 | Must read at 160px wide |
| Facebook / link preview (OG) | 1200 x 630 | 1.91:1 | Also used by Telegram link previews |
| Profile avatar | 1080 x 1080 | 1:1 | Shown as a circle; keep content inside the central 70% |

**Stories and Reels safe zones (1080 x 1920)**: keep text and logos out of the
top ~250px (profile bar) and the bottom ~350px (caption, buttons). Reels also
have action icons along the right ~120px. A Reels cover is cropped to the
central 4:5 or 3:4 area in the profile grid, so the title must sit inside the
central 1080 x 1350 zone.

**Rules for social posts**
- One message per frame. If there are two, it is a carousel.
- Minimum text size on a 1080px canvas: 32px for body, 28px for footnotes.
  Headlines 80px and up.
- Outer margin 64-90px on every side.
- The first frame is a hook: a number, a question, a bold claim, or a striking
  visual. It must work without the caption.
- Brand consistency across posts comes from a repeated system: same margins,
  same logo position and size, same two typefaces, same color logic. Offer the
  user a template set (cover, content slide, quote, offer, CTA slide) rather than
  one-off designs.

**Carousel structure**: 1) hook cover, 2) the problem or promise, 3-6) one idea
per slide with a large numeral or keyword, 7) summary, 8) CTA slide (follow,
write, link). Add a small "swipe" cue on the cover and a progress indicator or
slide number. Keep a continuous element (a line, a color band) running across
slides to pull the viewer forward.

## 2. Ad creatives

- Common placements: 1080 x 1350 (feed), 1080 x 1920 (stories/reels),
  1080 x 1080 (universal), 1200 x 628 (links and display).
- Build the set from one master concept so all sizes look related; re-compose
  for each ratio instead of stretching.
- Structure: hook (what stops the scroll) + offer (what they get) + proof
  (why believe it) + CTA (what to do). Three to seven words for the hook.
- Keep text short and large. Heavy text overlays reduce both reach and
  readability; let the visual and one line do the work.
- Show the product or the result, or a person from the target audience. Faces
  and concrete numbers outperform abstract graphics.
- Contact block (site, Telegram handle, phone) is small, aligned, in one place.
  Use the company's contacts, not personal accounts, unless told otherwise.
- Produce 2-3 variants that test one variable each (hook, visual, or color) and
  label what each variant tests.
- For video ads, design the first frame as a static poster with the hook, and
  provide a storyboard: frame, on-screen text, duration.

## 3. Web

- Landing page: desktop frame 1440px wide, content max-width 1120-1280px;
  mobile 360-390px wide. Design both.
- Hero must fit the first screen: headline, support line, CTA visible without
  scrolling at 1440 x 800 and on a 390 x 800 phone.
- Favicon 32x32 and 180x180; OG image 1200 x 630.
- Performance is part of design: inline SVG, CSS gradients and system or 1-2 web
  fonts instead of heavy images.

## 4. Presentations

- 1920 x 1080 (16:9).
- One idea per slide; the headline states the conclusion ("Savdo 3 oyda 42% ga
  oshdi"), not the topic ("Savdo natijalari").
- Minimum 28px for body text, 48px and up for headlines; margins 80-120px.
- Recurring layouts: title, section divider, statement, big number, two-column,
  image + text, comparison, chart, timeline, closing/contacts.
- Maximum about 30 words on a content slide. More text belongs in a document.
- Keep a consistent footer zone (logo, page number) and a consistent headline
  position on every slide.

## 5. Print

- Work in millimetres, CMYK thinking, 300 dpi. Add 3mm bleed on every side and
  keep text 5mm inside the trim.
- A4 210 x 297mm; A5 148 x 210mm; A6 105 x 148mm; business card 90 x 50mm
  (common locally) or 85 x 55mm; roll-up banner 850 x 2000mm; outdoor banner per
  printer's spec.
- Minimum text size 7-8pt; avoid hairlines under 0.25pt and light text on rich
  backgrounds at small sizes.
- Large formats are read from a distance: 5-7 words, huge type, one image, one
  contact route. A rough rule is 1cm of letter height per 3m of viewing distance.
- In HTML, build print pieces with `@page { size: ...; margin: 0 }` and mm units
  so the browser's "Save as PDF" gives the right size. Tell the user the printer
  may need a CMYK PDF with bleed and crop marks prepared in a print tool.
- Menus and price lists: align prices in a column, group by category, highlight
  2-3 hero items.

## 6. Logo and brand identity

A logo must work at 16px and on a signboard, in one color, on light and dark.

Process:
1. Extract the brand's core idea in one word (speed, trust, growth, care).
2. Explore 3 distinct routes: wordmark (custom type treatment), lettermark or
   monogram, and symbol + wordmark. Present them side by side.
3. Construct on a simple geometric grid with a small number of shapes. Fewer
   anchor points and consistent stroke widths look more professional.
4. Deliver as SVG with: primary lockup, horizontal and stacked versions, icon
   only, one-color black and white, reversed on dark, minimum size, clear space
   (usually the height of one letter on all sides), and a mock-up of real use
   (avatar circle, signboard, app icon, business card).

Avoid: gradients and effects in the primary mark, thin lines that vanish small,
clip-art metaphors (light bulb, globe, generic swoosh), more than 2 colors, and
anything resembling an existing well-known brand. Do not copy real logos.

A mini brand guide (one page) includes: logo versions and misuse examples, color
palette with hex and roles, typography with sizes, spacing and radius rules, icon
and photo style, and 3-4 sample applications (post, story, business card,
presentation slide).

## 7. Export notes

- HTML artboards: build at exact pixel size inside a wrapper that scales to fit
  the screen. State the export size next to each artboard.
- If a screenshot or headless browser tool is available, render PNG at 1x (or 2x
  for crispness) at the exact dimensions. Otherwise tell the user how to export
  (browser screenshot of the frame, or print to PDF for print pieces).
- SVG for logos and icons; PNG for social; PDF for print and presentations.
- Name files descriptively: `brand_post-aksiya_1080x1350_v1.png`.
