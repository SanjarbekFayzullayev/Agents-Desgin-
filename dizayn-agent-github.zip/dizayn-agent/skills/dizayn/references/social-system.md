# Social Content Systems

How to design a recognizable, reusable system for Instagram and Telegram instead
of one-off posts.

## Contents
1. System rules
2. Template set
3. Carousels
4. Stories
5. Reels and video covers
6. Video ad storyboard
7. Profile and grid
8. Telegram channel
9. Handoff to the person filling templates

## 1. System rules

Fix these once and never vary them inside a series:

- **Margins**: one value on all sides (64-90px on 1080px).
- **Logo**: one position (commonly a top or bottom corner), one size (about
  4-6% of the canvas height), one version.
- **Type**: one display and one text family; fixed sizes for headline, body and
  footnote.
- **Color logic**: a base and an accent, plus an optional rule that links color
  to content type (for example: tips on light, offers on the brand color,
  quotes on dark).
- **Signature element**: one repeated device (a shape, a line, a frame, a photo
  treatment, a numbering style).
- **Photo treatment**: one approach to crops, backgrounds and filters.

Test: cover the logo. If the post is still recognizable as the brand, the system
works.

## 2. Template set

| Template | Purpose | Key elements |
|---|---|---|
| Hook cover | Stop the scroll, open a carousel | 3-7 word headline, swipe cue |
| Tip / education | Give value | Number or keyword large, 1-2 sentences |
| Quote / review | Proof and voice | Quote marks as graphic, name and role |
| Offer | Sell | What, price or discount, deadline, CTA |
| Product / service | Show | Photo slot dominant, name, price |
| Announcement | Inform | Date and time largest, place, action |
| Case / result | Prove | Before -> after numbers, client type |
| CTA / contacts | Convert | One action, contact routes |

Build each with real sample content. Review quotes and case numbers are
placeholders until the user supplies real ones; mark them so.

## 3. Carousels

Structure: 1) hook, 2) why it matters, 3-6) one idea per slide, 7) summary or
checklist, 8) CTA.

- The cover promises a specific benefit ("Kassadagi 5 xato, ular pulingizni
  yeydi").
- One idea, one visual anchor (number, icon, word) and at most about 30 words
  per slide.
- Continuity: a line, shape or color band that crosses slide edges; consistent
  numbering; a progress marker.
- The last slide asks for exactly one action (save, write, follow, link).
- Alternate light and dark or text and image slides to keep rhythm.

## 4. Stories

- 1080 x 1920, text inside the central safe area (top ~250px and bottom ~350px
  clear).
- One thought per story; 3-5 stories make a sequence with a beginning and an
  end.
- Leave space for native stickers (poll, question, link) and say where they go.
- Large type (56px and up for the main line); stories are viewed for seconds.
- Template kinds: daily offer, question box, behind the scenes frame, review
  screenshot frame, countdown, "new post" teaser.

## 5. Reels and video covers

- Cover 1080 x 1920 with the title inside the central 4:5 area, because the
  profile grid crops it.
- 2-5 words in very large type, high contrast, a face or the subject visible.
- One consistent cover system across all Reels makes the profile look designed:
  same title position, same typeface, same color band.
- Avoid placing key content where the interface overlays it (bottom caption
  area and the right-side icons).

## 6. Video ad storyboard

Deliver a table the editor or videographer can follow:

| # | Duration | Visual | On-screen text | Voice / sound |
|---|---|---|---|---|
| 1 | 0-2s | Hook: the pain shown | 3-6 words | ... |
| 2 | 2-6s | The problem made concrete | ... | ... |
| 3 | 6-15s | The solution in use | ... | ... |
| 4 | 15-22s | Proof: number, client, result | ... | ... |
| 5 | 22-27s | Offer and CTA | Contact route | ... |

- The first 2 seconds decide everything: start with motion and the hook, not a
  logo.
- Design for sound off: every key point appears as on-screen text.
- Subtitles in a consistent style, large, inside safe zones.
- End card: logo, offer, one CTA and the company's official contacts.
- Also deliver the designed first frame and cover as static images.

## 7. Profile and grid

- Avatar: the icon version of the logo, centered, readable at 40px.
- Highlight covers: one simple icon or word per cover, same background and
  style.
- Bio: who it is for, what it does, proof, one CTA with a link.
- Grid: plan rows so colors and template types alternate; mock a 3x3 or 3x4
  preview so the owner sees the whole.
- Pinned posts: who we are, the main offer, the strongest proof.

## 8. Telegram channel

- Avatar readable in a small circle; channel name short.
- Post images: 1:1 or 4:5 read better in chat than wide images; 1280 x 720 for
  link-style headers.
- Text carries more weight than on Instagram: design a consistent post
  structure (bold headline, short paragraphs, a clear link or button).
- Pinned message with the main offer and contacts.
- Keep visual templates consistent with Instagram so the brand is one system.

## 9. Handoff to the person filling templates

Give a short guide:

- What may change: text, photo, choice of palette color by content type.
- What must not change: margins, logo, fonts, sizes.
- Maximum text lengths per template (for example, headline up to 6 words).
- Photo requirements: orientation, background, lighting.
- A weekly rhythm suggestion linking content pillars to templates.
