# Image Briefs and Prompts

The agent usually cannot create photographs. It can make the user's own photos
better through precise briefs, and write prompts for an image generator the user
has access to. This file covers both.

## Contents
1. Photo slots in a design
2. Photo brief for a photographer or a phone
3. Product photography basics
4. Prompts for image generators
5. Prompt examples
6. Choosing and treating images
7. Honesty and rights

## 1. Photo slots in a design

When a design needs a photo, draw the slot at its final proportion and position,
fill it with a neutral tone or a simple SVG placeholder, and label it with what
goes there: subject, angle, background, orientation. Example label: "Mahsulot
fotosi: 3/4 burchak, oq fon, yumshoq soya, vertikal 4:5".

Design the composition so the text never depends on an unknown image area: keep
text on solid color or on a scrim.

## 2. Photo brief for a photographer or a phone

Give the user a short shot list:

- **Purpose**: where each photo will be used and at what ratio.
- **Subject**: what must be visible and what must not.
- **Angle**: front, 3/4, top-down, eye level.
- **Background**: plain wall, paper sweep, real interior; brand color if any.
- **Light**: daylight by a window, from the side, no direct flash.
- **Space**: leave empty area on one side for text when needed.
- **People**: real staff or customers with their consent; natural action rather
  than posing for the camera.
- **Consistency**: same light, background and angle for every item in a series.
- **Quantity**: horizontal and vertical versions of each key shot.

Phone tips: clean the lens, use the main camera rather than zoom, tap to focus,
shoot near a window, hold the phone level, take several frames.

## 3. Product photography basics

- Catalog: plain light background, same angle and scale for all items, soft
  shadow, product fills about 80% of the frame.
- Lifestyle: product in use, in a real setting, with a clear focal point.
- Food: side or 45-degree light, fresh garnish, simple props, shoot quickly.
- Interiors: wide lens held straight, lights on, tidy the frame, daytime.
- Before/after: same position, angle, light and crop.

## 4. Prompts for image generators

Structure a prompt as: **subject + action/pose + setting + composition +
lighting + style/medium + color palette + technical notes + what to avoid**.

- Be concrete: materials, time of day, lens feeling ("shot at eye level,
  shallow depth of field").
- Name the composition: "subject on the right third, empty space on the left
  for text".
- Give the palette in words that match the brand.
- State the aspect ratio that the layout needs (4:5, 9:16, 16:9).
- Ask for no text in the image; add text in the layout, where it stays sharp
  and editable.
- Generate backgrounds, textures and atmospheres more freely than products:
  the customer must receive the real product, so use real product photos for
  anything being sold.

## 5. Prompt examples

**Background for a SaaS hero**
"Minimal abstract composition of soft overlapping paper layers in deep teal and
warm cream, subtle shadows, generous empty space in the upper left, studio
lighting, clean modern editorial style, no text, 16:9"

**Lifestyle scene for a shop automation service**
"A shop owner in a small modern bookstore standing at the counter with a tablet,
warm afternoon window light, shelves softly blurred behind, candid moment,
subject on the right third with empty space on the left, natural colors with a
teal accent, photographic, no text, 4:5"

**Food hero**
"A plate of freshly served plov on a ceramic dish, on a dark wooden table, steam
visible, side daylight, shallow depth of field, a few simple props, rich warm
tones, top-left area empty for a headline, photographic, no text, 4:5"

**Pattern for a heritage-style brand**
"Seamless geometric ornament inspired by traditional Central Asian tile work,
simplified modern line style, two colors: deep blue on cream, flat vector look,
no text, 1:1"

Adapt the wording to the tool the user has; different generators respond to
different phrasing, so expect to iterate.

## 6. Choosing and treating images

- One strong image beats a collage.
- Faces looking toward the text or CTA guide attention there.
- Crop boldly; let the subject touch or leave the frame.
- Unify a mixed set with one treatment: same crop ratio, a duotone, a color
  overlay, or consistent background removal.
- Check resolution at final size; an enlarged small image ruins a premium
  layout.
- For text over an image, add a scrim or place text in a calm area and check
  contrast against the lightest part.

## 7. Honesty and rights

- Do not present generated images as real photos of the client's product,
  premises, team or customers. Label illustrations and renders where the viewer
  could be misled.
- Do not use photos of real people without their consent, and do not use images
  of celebrities or public figures in advertising.
- Use only images the user owns or has a license for; stock and web images have
  usage terms. When unsure, recommend the user's own photos.
- Do not recreate other brands' logos, characters or artworks.
