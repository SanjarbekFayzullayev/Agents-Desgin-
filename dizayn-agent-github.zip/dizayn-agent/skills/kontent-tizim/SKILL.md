---
name: kontent-tizim
description: This skill should be used when the user asks for a series or system of social media visuals rather than one piece - "Instagram shablonlar", "post shablonlari", "karusel yasa", "kontent dizayni", "profil dizayni", "Reels muqovalari", "bir haftalik postlar", "SMM dizayn", "story shablon", "highlight muqova", "Telegram kanal dizayni", "video reklama raskadrovka". It produces a reusable template set, carousels and storyboards in one consistent visual system.
---

# Kontent-tizim

One beautiful post does not build a brand; a recognizable system does. Deliver a
set of templates the owner or their SMM person can reuse for months.

Memory: follow the `xotira` skill. Read `DIZAYN-XOTIRA.md` before starting and update it before the final message. For the tasbeh project, apply `../dizayn/references/tasbeh-project.md`, including its respect and accuracy rules.

## Steps

1. **Brief.** Identify the brand assets (logo, colors, fonts), platform (Instagram,
   Telegram or both), language, content pillars (what they post about) and who
   will fill the templates afterwards. If there is a brand profile, use it. If
   there is no brand at all, propose a light identity first (palette, two fonts,
   signature element) and confirm it in two lines.
2. **Define the system rules** before drawing: margins, logo position and size,
   type sizes for headline, body and footnote, color logic (which color means
   which content type), signature element, photo treatment. Rules are in
   `../dizayn/references/social-system.md`.
3. **Build the template set** on one labelled board, each at exact size
   (`../dizayn/references/formats.md`). A standard set:
   - cover / hook post,
   - educational or tip slide,
   - quote or testimonial (with clearly marked placeholder text, never an
     invented review),
   - offer / promotion,
   - product or service showcase with a photo slot,
   - announcement,
   - CTA / contacts slide,
   - story template and Reels cover,
   - highlight covers and avatar when a profile refresh is requested.
   Fill every template with realistic content for this business in the user's
   language so the hierarchy can be judged.
4. **For a carousel**, write and design the full sequence: hook, promise, one idea
   per slide, summary, CTA. Add a swipe cue and a progress marker.
5. **For video ads or Reels**, deliver a storyboard table (frame, visual,
   on-screen text, voiceover, duration) plus a designed cover and first frame.
6. **Show the grid.** Mock a 3x3 profile grid using the templates so the user sees
   how the feed will look as a whole.
7. **Usage notes**: a short guide for whoever fills the templates - what can
   change (text, photo, color within the palette) and what must not (margins,
   logo, fonts).
8. **Check**: every frame readable at phone size, text inside safe zones, the
   series recognizable with the logo covered, contrast passing.

## Standards

- One message per frame; more than one becomes a carousel.
- Minimum 32px body text on a 1080px canvas.
- Use the company's official contacts on CTA slides; ask if unknown.
- Content must be truthful: placeholders for prices, dates and reviews are
  marked as placeholders.
- For sales copy on offer slides, follow
  `../dizayn/references/conversion-copy.md`.
