---
name: brend-kit
description: This skill should be used when the user asks for a logo, brand identity, brand book, style guide, rebranding, company colors and fonts, or a name and slogan - "logo yasa", "brend yarat", "firma stili", "brendbuk", "rebrending", "rang va shrift tanla", "nom o'ylab ber", "brand kit", "brand guidelines". It produces positioning, logo options and a one-page brand guide with sample applications.
---

# Brend-kit

Build a usable brand identity for a small or medium business: strategy first, then
the mark, then the system, then proof that it works in real use.

Memory: follow the `xotira` skill. Read `DIZAYN-XOTIRA.md` before starting and update it before the final message. For the tasbeh project, apply `../dizayn/references/tasbeh-project.md`, including its respect and accuracy rules.

## Steps

### 1. Strategy

If positioning, audience and personality are not already clear, run the
brend-strateg agent (or do its work yourself when agents are unavailable) to
produce the one-page brand brief. Method and templates are in
`../dizayn/references/brand-strategy.md`. Confirm the brief with the user in two
or three lines before drawing; a logo built on the wrong positioning is wasted
work. If the user provides an existing brief or just wants a refresh of a known
brand, skip ahead.

### 2. Logo routes

Explore three distinct routes and present them side by side on one board:

- a wordmark with a custom type treatment,
- a lettermark or monogram,
- a symbol plus wordmark.

Each route gets one sentence on the idea behind it. Construct every mark in SVG on
a simple geometric grid, with few shapes and consistent stroke widths. Show each
at large size, at 32px, in one color, and reversed on dark. Rules, pitfalls and
deliverables are in `../dizayn/references/formats.md` (section 6).

Recommend one route and say why; then refine the route the user picks.

Never imitate an existing company's logo. Remind the user that name and mark
availability (trademark, domain, handles) must be checked before launch, and that
this check needs a proper search or a specialist.

### 3. System

Around the chosen mark, define:

- palette with hex values and roles (brand, accent, neutrals, semantic),
- typography: display and text families, scale, usage, with Uzbek and Russian
  glyph support verified (`../dizayn/references/typography-color.md`),
- shape language: radius, line weight, pattern or signature element,
- icon and photo style,
- tone of voice in three do/don't lines.

### 4. Applications

Prove the system on 4-6 real touchpoints chosen for this business, for example:
Instagram avatar and post template, story template, business card, signboard or
storefront, packaging or bag, presentation title slide, website header, staff
uniform or receipt.

### 5. Brand guide

Assemble a one-page guide (HTML, printable): logo versions with clear space and
minimum size, misuse examples, palette, typography, shape rules, imagery style,
voice, and the applications. Also deliver the logo as separate SVG files
(primary, horizontal, stacked, icon, one-color, reversed).

Finish by writing the approved logo, palette, typography and rules into the
memory file `DIZAYN-XOTIRA.md` (see the `xotira` skill), so every later design
stays on brand.

### 6. Review

Self-check against the logo criteria: works at 16px, works in one color, works on
light and dark, is distinct from competitors, and is easy to describe in a
sentence. For a full kit, get an independent review from the dizayn-tanqidchi
agent when available and apply its top fixes.
