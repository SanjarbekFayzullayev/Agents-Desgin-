# DIZAYN XOTIRA

Bu fayl dizayn agentining xotirasi. Agent har ish boshida o'qiydi, har ish
oxirida yangilaydi. Siz ham istalgan payt qo'lda tahrirlashingiz mumkin.
`[aniqlanmagan]` - hali so'ralmagan yoki tasdiqlanmagan ma'lumot.

Oxirgi yangilanish: [sana]

## 1. Loyiha

- Loyiha: Tasbeh (ilova + market)
- Brend nomi: [aniqlanmagan]
- Mahsulot turi (oddiy tasbeh / raqamli hisoblagich / aqlli qurilma): [aniqlanmagan]
- Ilova holati (g'oya / ishlab chiqilmoqda / chiqqan), platformalar: [aniqlanmagan]
- Market (ilova ichida / sayt / ikkalasi), nima sotiladi: [aniqlanmagan]
- Asosiy maqsad (hozirgi bosqichda): [aniqlanmagan]

## 2. Auditoriya va pozitsiya

- Asosiy auditoriya: [aniqlanmagan]
- Pozitsiya (1 gap): [aniqlanmagan]
- Farqlanish: [aniqlanmagan]
- Brend xarakteri (3 so'z): [aniqlanmagan]
- Ovoz ohangi: [aniqlanmagan]

## 3. Vizual tizim (tasdiqlangan)

- Logo: [aniqlanmagan]
- Ranglar (hex + roli): [aniqlanmagan]
- Shriftlar (sarlavha / matn / arabcha): [aniqlanmagan]
- Uslub yo'nalishi: [aniqlanmagan]
- Imzo element: [aniqlanmagan]
- Burchak radiusi, chiziq qalinligi: [aniqlanmagan]
- Foto uslubi: [aniqlanmagan]
- Tungi rejim: [aniqlanmagan]

## 4. Qoidalar va cheklovlar

- Tillar: [aniqlanmagan]
- Odamlar va yuz tasviri bo'yicha xohish: [aniqlanmagan]
- Diniy matnlarni kim tasdiqlaydi: [aniqlanmagan]
- Tasdiqlangan diniy matnlar va manbalari: [yo'q]
- Hech qachon qilinmaydigan narsalar: [aniqlanmagan]

## 5. Kontaktlar (reklama va CTA uchun)

- Sayt: [aniqlanmagan]
- Telegram: [aniqlanmagan]
- Telefon: [aniqlanmagan]
- Instagram: [aniqlanmagan]
- Ilova havolasi (Google Play / App Store): [aniqlanmagan]

## 6. Egasining didi va fikrlari

Yoqadi:
- 

Yoqmaydi:
- 

Doimiy talablar:
- 

## 7. Tasdiqlangan raqamlar va dalillar

(faqat shu yerdagilar dizaynda haqiqiy ma'lumot sifatida ishlatiladi)
- 

## 8. Fayllar va holati

| Fayl | Nima | Holati (qoralama / tasdiqlangan / almashtirilgan) | Sana |
|---|---|---|---|

## 9. Ochiq savollar

- 

## 10. Takrorlanadigan xatolar (tanqidchi qaydlari)

- 

## 11. Ish jurnali

| Sana | Nima qilindi | Natija |
|---|---|---|

## 12. Tarix (o'zgargan qarorlar)

- 
