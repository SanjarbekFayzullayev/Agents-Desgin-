---
name: xotira
description: This skill should be used at the start and at the end of every design task, and whenever the user says "eslab qol", "xotiraga yoz", "buni unutma", "nimani eslaysan", "xotirani ko'rsat", "buni unut", "xotirani yangila", "remember this", "what do you remember". It gives the design team a persistent memory - a project file holding the brand profile, approved decisions, the owner's preferences and feedback, and a work log - so each new session continues from where the last one stopped instead of starting from zero.
---

# Xotira: the design team's memory

A designer who forgets the brand colors every morning is useless. This skill
gives the team a memory that survives between sessions by keeping it in a plain
file the owner can read and edit: `DIZAYN-XOTIRA.md`.

The plugin's own files cannot be changed while it runs, so memory lives outside
the plugin, in the user's own space. Be honest with the user about where it is
and whether it was saved.

## Where the memory file lives

Look for `DIZAYN-XOTIRA.md` in this order and use the first one found:

1. The user's connected working folder or project folder (a `dizayn-xotira/`
   subfolder or the folder root).
2. The current working directory of the session.
3. Files attached to the conversation or stored in the project's knowledge.
4. The conversation itself (pasted earlier).

If none exists, create one from `assets/DIZAYN-XOTIRA.md` (the template is
pre-set for the Tasbeh project) in the best persistent place available: a
connected folder if there is one, otherwise the working directory.

After creating or updating it, tell the user in one line where it is. If the
session has no place that survives after it ends (a plain chat with no connected
folder), send the updated file to the user and say plainly: "Xotira faylini
saqlab qo'ying va keyingi safar biriktiring (yoki loyiha fayllariga qo'ying),
shunda hammasini eslab qolaman." Never claim something was remembered when it
was only kept in the current conversation.

If the session also offers a built-in memory feature, the file remains the
source of truth for design decisions; do not rely on anything else for them.

## At the start of every task

1. Find and read the memory file before asking any question or drawing
   anything.
2. Apply it silently: brand colors, fonts, logo rules, contacts, tone,
   approved style, things the owner dislikes. Do not ask again for anything
   already recorded.
3. If a required fact is missing (marked `[aniqlanmagan]`), ask only for what
   this task needs, at most 3 questions, and record the answers.
4. First run on an empty profile: ask the short onboarding set below, then
   start the work in the same turn if the answers allow.

Onboarding questions (only those not already known):
- Brend nomi va mahsulot aynan nima (oddiy tasbeh, raqamli hisoblagich, aqlli
  qurilma)? Ilova va market hozir bormi?
- Logo, ranglar, shriftlar bormi yoki noldan tanlaymizmi?
- Qaysi tillarda (o'zbek lotin, kirill, rus, boshqa)?
- Rasmiy kontaktlar va odamlar tasvirini ishlatish bo'yicha xohish.

## At the end of every task

Update the file before the final message. Record only what will matter next
time:

- **Decisions**: anything chosen or approved (palette, typeface, logo route,
  layout rule, template), with the date.
- **Feedback and preferences**: what the owner liked, rejected or corrected,
  in their own words where possible ("oltin gradient yoqmaydi", "matn
  kattaroq bo'lsin").
- **Assets**: files produced and their status (draft, approved, replaced).
- **Facts**: new verified facts about the product, audience, prices, contacts.
- **Open items**: what is waiting for the owner's answer or approval.
- **Work log**: one line per task: date, what was made, result.

Rules for writing:
- Read the current file first and edit it; never overwrite it blind and never
  drop existing lines you did not mean to change.
- A new decision replaces the old one in its section; move the old one to
  "Tarix" with the date so the reason for the change is not lost.
- Write facts the owner stated or approved. Mark your own unconfirmed
  proposals as "taklif" until approved. Do not record guesses as facts.
- Keep it short. When the work log passes about 30 lines, compress older
  entries into a few summary lines.
- Dates in YYYY-MM-DD.
- Write the file in the owner's language (Uzbek Latin by default).

## What never goes into memory

Passwords, access keys, card or bank details, personal documents, private
information about customers or other people, and anything the owner asks not to
keep. Religious texts are stored only when the owner supplied and approved
them, with the source noted.

## When the user asks about memory

- "Nimani eslaysan?": read the file and summarize it plainly by section.
- "Eslab qol ...": write it to the right section now and confirm in one line.
- "Buni unut ...": delete that line completely (do not keep it as history) and
  confirm.
- "Xotirani tozala": confirm once, then reset to the template.
- If a save fails, say so; do not pretend.

## How the agents use it

art-direktor reads everything and writes decisions, assets and the log.
brend-strateg writes positioning, audience, voice and naming decisions.
dizayn-tanqidchi reads the profile to judge brand fit and records recurring
problems under "Takrorlanadigan xatolar" so the team stops repeating them.
