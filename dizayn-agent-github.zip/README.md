# masalahal-plugins

Claude uchun plaginlar to'plami.

| Plagin | Tavsif |
|---|---|
| [dizayn-agent](./dizayn-agent) | Tasbeh loyihasi (ilova + market) uchun AI dizayn jamoasi |

## O'rnatish (Claude Code)

```
/plugin marketplace add <egasi>/<repo>
/plugin install dizayn-agent@masalahal-plugins
```

Claude ilovasida: plaginlar bo'limida shu repozitoriy manzilini marketplace sifatida qo'shing.
